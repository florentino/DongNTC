﻿using NTC_Consolidator.Core.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NTC_Consolidator.Data;
using System.Data.Entity;
using System.Data.Entity.Validation;

namespace NTC_Consolidator.Core.Repository
{
    public class QualifyingCapitalRepository : IQualifyingCapital, IDisposable
    {
        private NTC_Context_Entities context;
        DbSet<BDOLF_QualifyingCapital> _bjectSet;

        public QualifyingCapitalRepository(NTC_Context_Entities context)
        {
            this.context = context;
            _bjectSet = context.Set<BDOLF_QualifyingCapital>();
        }

        public void DeleteQCapital(string QDate)
        {
            throw new NotImplementedException();
        }

        public void DeleteQCapital(int QID)
        {
            try
            {
                var original = context.BDOLF_QualifyingCapital.Where(a => a.QualifyingCapitalID == QID).First();

                context.BDOLF_QualifyingCapital.Remove(original);
                context.SaveChanges();
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        public IEnumerable<BDOLF_QualifyingCapital> GetAll()
        {
            var query = context.BDOLF_QualifyingCapital.OrderByDescending(a => a.RefDate).ToList();

            return query;
        }

        public BDOLF_QualifyingCapital GetByCode(string QDate)
        {
            var parameter = Convert.ToDateTime(QDate);

            var firstDayOfMonth = new DateTime(parameter.Year, parameter.Month, 1);
            var lastDayOfMonth = new DateTime(parameter.Year, parameter.Month, DateTime.DaysInMonth(parameter.Year, parameter.Month));

            var result = context.BDOLF_QualifyingCapital.Where(a => (a.RefDate >= firstDayOfMonth && a.RefDate <= lastDayOfMonth)).FirstOrDefault();

            return result;
        }

        public BDOLF_QualifyingCapital GetByID(int QID)
        {
            throw new NotImplementedException();
        }

        public void InsertQCapital(BDOLF_QualifyingCapital QCapital)
        {
            context.Set<BDOLF_QualifyingCapital>().Add(QCapital);
            context.SaveChanges();
        }

        public void TruncateTable()
        {
            throw new NotImplementedException();
        }

        public void UpdateQCapital(BDOLF_QualifyingCapital QCapital)
        {
            var original = context.BDOLF_QualifyingCapital.Find(QCapital.QualifyingCapitalID);
            original.Description = QCapital.Description;
            original.Amount = QCapital.Amount;
            original.CreatedBy = QCapital.CreatedBy;
            original.CreatedDate = QCapital.CreatedDate;
            original.isDeleted = QCapital.isDeleted;

            context.Entry<BDOLF_QualifyingCapital>(context.Set<BDOLF_QualifyingCapital>().Find(QCapital.QualifyingCapitalID)).CurrentValues.SetValues(original);
            context.SaveChanges();
        }


        public void Save()
        {
            try
            {
                context.SaveChanges();
            }
            catch (DbEntityValidationException dbEx)
            {
                foreach (var validationErrors in dbEx.EntityValidationErrors)
                {
                    foreach (var validationError in validationErrors.ValidationErrors)
                    {
                        System.Console.WriteLine("Property: {0} Error: {1}", validationError.PropertyName, validationError.ErrorMessage);
                    }
                }
            }
        }

        private bool disposed = false;

        protected virtual void Dispose(bool disposing)
        {
            if (!this.disposed)
            {
                if (disposing)
                {
                    context.Dispose();
                }
            }
            this.disposed = true;
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
    }
}
