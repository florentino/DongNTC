﻿namespace NTC_Consolidator.ReportSource
{
}

namespace NTC_Consolidator.ReportSource {
    
    
    public partial class dssummary {
    }
}
namespace NTC_Consolidator.ReportSource {
    
    
    public partial class dssummary {
    }
}
