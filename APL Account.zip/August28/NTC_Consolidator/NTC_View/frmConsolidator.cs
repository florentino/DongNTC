﻿using MetroFramework;
using Microsoft.Reporting.WinForms;
using NTC_Consolidator.Core.Interfaces;
using NTC_Consolidator.Core.Repository;
using NTC_Consolidator.Data;
using NTC_Consolidator.Helper;
using NTC_Consolidator.NTC_Model;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.Entity.Validation;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows.Forms;

namespace NTC_Consolidator.NTC_View
{
    public partial class frmConsolidator : MetroFramework.Forms.MetroForm
    {
        private static string Role = "";
        public static string UserName = "";
        public static string dbUserName = "";
        public static string dbPassword = "";
        private static string[] param = new string[10];
        private string _IcbsPath = "";
        private string _IcbsFolder = "";
        private string _AafFolder = "";
        public static string _AafPath = "";
        private string _FamsFolder = "";
        public static string _FamsPath = "";
        BindingSource source = new BindingSource();
        DataTable dtTmp = new DataTable();
        DataTable dtcompare = new DataTable();
        DataTable dtConso = new DataTable();
        DataTable dtGLCODE;
        DataTable dtIcbs;
        DataTable dtAaf;
        DataTable dtFams;
        DataTable dtExport;
        bool isPreviousDate = false;
        bool dateNotTheSame = false;
        int lineCount = 0;
        int iCounter = 1;
        bool isInProcess = false;
        bool _InValidDate = false;
        bool isPreviousData = false;
        string ICBSDateParameter = "";
        string AAFDateParameter = "";
        string FAMSDateParameter = "";
        int curRow = 0;
        decimal currencyRate = 0.0M;
        string[] progressArray;
        string ExportFilename = "";
        bool isICBSReadyToProcess = false;
        bool isAAFReadyToProcess = false;
        bool isFAMSReadyToProcess = false;
        bool IsBusy = false;

        bool isICBSExist = false;
        bool isAAFExist = false;
        bool isFAMSExist = false;

        NumberStyles styles;

        private BackgroundWorker icbsWorker;
        private BackgroundWorker aafWorker;
        private BackgroundWorker famsWorker;
        private BackgroundWorker consolidateWorker;
        private BackgroundWorker ExportWorker;
        private BackgroundWorker updateGLworker;

        CultureInfo cultureInfo;
        TextInfo textInfo;

        AAFModel consoModel;
        AAFModel famsmodel;
        AAFModel icbsmodel;
        AAFModel aafmodel;

        string icbsFileName = "";
        string famsFileName = "";
        string aafFileName = "";

        private ICorrespondingGLRepository correspondingGLRepository;
        private IConsolidator consolidatorRepository;
        private IFilePathRepository filePathRepository;
        private IExchangeRate exchangeRate;

        private static frmConsolidator frmconsolidator = null;
        public static frmConsolidator Instance(string _Role, string _UserName, string _dbUsername, string _dbpassword)
        {
            if (frmconsolidator == null)
            {
                frmconsolidator = new frmConsolidator();
            }
            Role = _Role;
            UserName = _UserName;
            dbUserName = _dbpassword;
            dbPassword = _dbpassword;

            return frmconsolidator;
        }

        public frmConsolidator()
        {
            InitializeComponent();

            this.consolidatorRepository = new ConsolidatorRepository(new NTC_Context_Entities());
            this.filePathRepository = new FilePathRepository(new NTC_Context_Entities());
            this.exchangeRate = new ExchangeRateRepository(new NTC_Context_Entities());
            this.correspondingGLRepository = new CorrespondingGLRepository(new NTC_Context_Entities());

            lblBusy.Text = "";

            pnlWaitInfo.Location = new Point(
            this.ClientSize.Width / 2 - pnlWaitInfo.Size.Width / 2,
            this.ClientSize.Height / 2 - pnlWaitInfo.Size.Height / 2);
            pnlWaitInfo.Visible = false;

            this.ConsoMenu.RenderMode = ToolStripRenderMode.Professional;
            this.ConsoMenu.Renderer = new ToolStripProfessionalRenderer(new CustomColorTable());

            // GridColumn();

            //dgvConsolidator
        }

        public List<string> GetColumnNames()
        {
            var properties = (from t in typeof(BDOLF_Consolidator).GetProperties()
                              select t.Name).ToList();

            return properties;
        }

        private void frmConsolidator_Load(object sender, EventArgs e)
        {
            #region Remove Negative(-) Amount inside the parentheses
            styles = NumberStyles.AllowParentheses | NumberStyles.AllowTrailingSign | NumberStyles.Float | NumberStyles.AllowThousands;
            #endregion
            GetConsolidator();
        }

        private void GridColumn()
        {
            // var name = GetImageFromManifest("TempNamespace.Wait.gif");



            //dtLoader.Columns.Add("ProcessID");
            //dtLoader.Columns.Add("Status");
            //dtLoader.Columns.Add("Message");
            //dtLoader.Columns.Add("FilePath");
            //dtLoader.Columns.Add("Result");
            //DataRow dr = null;

            //dr = dtLoader.NewRow();
            //dr["ProcessID"] = 1;
            //dr["Status"] = "";///Image.FromFile(@"NTC_Consolidator.Properties.Resources.Spinner6");
            //dr["Message"] = "Validating ICBS Raw Files";
            //dr["FilePath"] = _IcbsPath;
            //dr["Result"] = "In Progress";
            //dtLoader.Rows.Add(dr);

            //dr = dtLoader.NewRow();
            //dr["ProcessID"] = 2;
            //dr["Status"] = "";
            //dr["Message"] = "Validating AAF DAta From Server";
            //dr["FilePath"] = "...";
            //dr["Result"] = "Pending";
            //dtLoader.Rows.Add(dr);

            //dr = dtLoader.NewRow();
            //dr["ProcessID"] = 3;
            //dr["Status"] = "";
            //dr["Message"] = "Validating FAMS DAta From Server";
            //dr["FilePath"] = "...";
            //dr["Result"] = "Pending";
            //dtLoader.Rows.Add(dr);
        }

        private bool CheckIDirectoryIfExists(string fileDir, string module)
        {
            DirectoryInfo info = new DirectoryInfo(fileDir);
            FileInfo[] files = info.GetFiles().OrderBy(p => p.CreationTime).ToArray();

            bool exists = Directory.Exists(fileDir);
            var retValue = false;

            #region ICBS Checker
            if (exists && module == "icbs")
            {
                //foreach (string f in System.IO.Directory.EnumerateFiles(fileDir, "*" + "ICBS" + "*.txt*"))
                //{
                //    //_IcbsPath = f;
                //    retValue = true;
                //    break;
                //}

                foreach (FileInfo file in files)
                {
                    _IcbsPath = file.FullName;
                    retValue = true;
                    break;
                }

                lineCount = File.ReadAllLines(_IcbsPath).Length;//may error kc ung path hnd naka specify
                lblWaitFilePath.Text = _IcbsPath;
                lblWaitStatus1.Text = string.Format("Total numbers of records: {0}", lineCount);
            }
            #endregion

            #region AAF Checker
            if (exists && module == "aaf")
            {
                //foreach (string f in System.IO.Directory.EnumerateFiles(fileDir, "*" + "AGING" + "*.xls*"))
                //{
                //    // _AafPath = f;
                //    retValue = true;
                //    break;
                //}

                //if (!retValue)
                //{
                //    foreach (string f in System.IO.Directory.EnumerateFiles(fileDir, "*" + "AGING" + "*.xlsx*"))
                //    {
                //        // _AafPath = f;
                //        retValue = true;
                //        break;
                //    }
                //}

                foreach (FileInfo file in files)
                {
                    _AafPath = file.FullName;
                    retValue = true;
                    break;
                }
            }
            #endregion

            #region FAMS Checker
            if (exists && module == "FACTOREDRECEIVABLE")
            {
                //foreach (string f in System.IO.Directory.EnumerateFiles(fileDir, "*" + "FACTOREDRECEIVABLE" + "*.xls*"))
                //{
                //    retValue = true;
                //    break;
                //}

                //if (!retValue)
                //{
                //    foreach (string f in System.IO.Directory.EnumerateFiles(fileDir, "*" + "FACTOREDRECEIVABLE" + "*.xlsx*"))
                //    {
                //        retValue = true;
                //        break;
                //    }
                //}

                foreach (FileInfo file in files)
                {
                    _FamsPath = file.FullName;
                    retValue = true;
                    break;
                }
            }
            #endregion

            return retValue;
        }

        private void btnGenerate_Click(object sender, EventArgs e)
        {
            if (!IsBusy)
            {
                consoModel = new AAFModel();

                DataTable dtpath = new DataTable();
                dtIcbs = new DataTable("ICBSDATA");

                var pathdata = filePathRepository.GetAll();

                foreach (var item in pathdata)
                {
                    icbsFileName = item.ICBSFilePath;
                    aafFileName = item.AAFFilePath;
                    famsFileName = item.FAMSFilePath;
                }

                if (pathdata.ToList().Count <= 0)
                {
                    MetroMessageBox.Show(this, "\r\nThe specified path of Raw File does not exists.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    return;
                }
                else
                {
                    isICBSReadyToProcess = CheckIDirectoryIfExists(icbsFileName, "icbs");
                    isAAFReadyToProcess = CheckIDirectoryIfExists(aafFileName, "aaf");
                    isFAMSReadyToProcess = CheckIDirectoryIfExists(famsFileName, "FACTOREDRECEIVABLE");

                    if (!isICBSReadyToProcess || !isAAFReadyToProcess || !isFAMSReadyToProcess)
                    {
                        MetroMessageBox.Show(this, "\r\nThe Raw File does not exists.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                        return;
                    }
                }

                var curresult = exchangeRate.GetByCode("PHP");

                if (curresult == null)
                {
                    MetroMessageBox.Show(this, "\r\nCurrency Rate table for the current month is not updated.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    return;
                }

                currencyRate = curresult.CurrencyRate;

                LoadGLData();

                pnlWaitInfo.Visible = true;
                lblWaitInfo.Text = "Initializing, Please wait...";
                lblWaitStatus.Text = "Status: Initializing...";

                if (isICBSReadyToProcess)
                {
                    progressArray = new string[5];
                    progressArray[1] = "Initializing, Please wait...";

                    icbsWorker = new BackgroundWorker();
                    icbsWorker.WorkerReportsProgress = true;
                    icbsWorker.DoWork += new DoWorkEventHandler(icbsWorker_DoWork);
                    icbsWorker.RunWorkerCompleted += new RunWorkerCompletedEventHandler(icbsWorker_RunWorkerCompleted);
                    icbsWorker.ProgressChanged += new ProgressChangedEventHandler(icbsWorker_ProgressChanged);
                    icbsWorker.WorkerSupportsCancellation = true;
                    icbsWorker.RunWorkerAsync();
                }
            }
            else
            {
                lblBusy.Text = "Busy processing, Please wait...";
            }
        }

        #region ICBS Worker
        private void icbsWorker_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            string[] labelsreports = (string[])e.UserState;
            lblWaitInfo.Text = labelsreports[1];
            lblWaitStatus.Text = string.Format("Status: Reading at row {0} out of {1}", curRow, lineCount);
        }

        private void icbsWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (e.Cancelled)
            {
                pnlWaitInfo.Visible = false;
                lblWaitInfo.Text = "";
                lblWaitStatus.Text = "Status: Error";

                isICBSExist = false;
                isAAFExist = false;
                isFAMSExist = false;

                if (isPreviousData)
                {
                    MetroMessageBox.Show(this, "\r\nSorry! System will not allow the user to insert a record from previous Months or Year.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }
                if (_InValidDate)
                {
                    MetroMessageBox.Show(this, "\r\nICBS Raw File date is Invalid Date.", "Invalid Date", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }
                else
                {
                    MetroMessageBox.Show(this, "\r\nOop! Something went wrong and couldn't process your request.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }

                dtIcbs = new DataTable("ICBSDATA");//Initialize again the datatable to avoid Error

            }
            else if (e.Error != null)
            {
                lblWaitStatus.Text = "Status: Error Encountered while processing";
                dtIcbs = new DataTable("ICBSDATA");//Initialize again the datatable to avoid Error
                return;
            }
            else
            {
                lblWaitInfo.Text = "Initializing, Please wait...";
                lblWaitStatus.Text = "Status: Initializing...";
                //progressConso.Value = 100;
                //lblPercent.Text = 100 + " %";
                lblBusy.Text = "";
                lblWaitStatus.Text = string.Format("Status: Completed");
                Thread.Sleep(500);

                if (isAAFReadyToProcess)
                {
                    progressArray = new string[5];
                    lineCount = 0;
                    curRow = 0;
                    AAFDataTable();
                    lblWaitInfo.Text = "Fetching Data from AAF Raw file, Please wait...";
                    lblWaitStatus.Text = "Status: Processing...";

                    aafWorker = new BackgroundWorker();
                    aafWorker.WorkerReportsProgress = true;
                    aafWorker.DoWork += new DoWorkEventHandler(aafWorker_DoWork);
                    aafWorker.RunWorkerCompleted += new RunWorkerCompletedEventHandler(aafWorker_RunWorkerCompleted);
                    aafWorker.ProgressChanged += new ProgressChangedEventHandler(aafWorker_ProgressChanged);
                    aafWorker.WorkerSupportsCancellation = true;
                    aafWorker.RunWorkerAsync();
                }
            }
        }

        private void icbsWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            IsBusy = true;
            #region For ICBS
            ArrayList icbsdata = new ArrayList();

            icbsFileName = Path.GetFileName(_IcbsPath);
            try
            {
                using (StreamReader sr = new StreamReader(_IcbsPath))
                {
                    string[] headers = sr.ReadLine().Split('|');

                    foreach (var headername in headers)
                    {
                        var headercolumn = headername.ToString().Trim();

                        if (headername != "")
                        {
                            #region Change Column Name
                            headercolumn = headername.ToString().Trim() == "PN Number" ? "AccountNo" : headercolumn;
                            headercolumn = headername.ToString().Trim() == "Customer Name" ? "ClientName" : headercolumn;
                            headercolumn = headername.ToString().Trim() == "Officer (AO Code)" ? "AO" : headercolumn;
                            headercolumn = headername.ToString().Trim() == "Product Description" ? "FacilityCode" : headercolumn;
                            headercolumn = headername.ToString().Trim() == "Status Code" ? "StatusPerSystem" : headercolumn;
                            headercolumn = headername.ToString().Trim() == "Book Date" ? "ValueDate" : headercolumn;
                            headercolumn = headername.ToString().Trim() == "Maturity Date" ? "MaturityDate" : headercolumn;
                            headercolumn = headername.ToString().Trim() == "Amount Financed" ? "TotalLoan" : headercolumn;
                            headercolumn = headername.ToString().Trim() == "O/S Bal. (Orig)" ? "OB" : headercolumn;
                            headercolumn = headername.ToString().Trim() == "AIR (Orig)" ? "AccruedInterestReceivable" : headercolumn;
                            headercolumn = headername.ToString().Trim() == "New Int. Rate" ? "OriginalRate" : headercolumn;
                            headercolumn = headername.ToString().Trim() == "Current Int. Rate" ? "CurrentRate" : headercolumn;
                            headercolumn = headername.ToString().Trim() == "Term in months" ? "TermInMonths" : headercolumn;
                            headercolumn = headername.ToString().Trim() == "Rate Type" ? "AAFICBSRateType" : headercolumn;
                            headercolumn = headername.ToString().Trim() == "Non-Accrual Date" ? "PastDueDateITLDateExtractedPerAAFICBS" : headercolumn;
                            headercolumn = headername.ToString().Trim() == "Industry Classification" ? "PerFaMSAAFICBSIndustryCode" : headercolumn;
                            headercolumn = headername.ToString().Trim() == "Class Description" ? "IndustryHeader" : headercolumn;
                            headercolumn = headername.ToString().Trim() == "Class Description 2" ? "IndustryDetail" : headercolumn;
                            // headercolumn = headername.ToString().Trim() == "Collateral Code" ? "Collateral" : headercolumn;
                            headercolumn = headername.ToString().Trim() == "Size of Firm" ? "PerFaMSAAFICBSAssetSize" : headercolumn;
                            headercolumn = headername.ToString().Trim() == "Branch No." ? "CostCenter" : headercolumn;
                            headercolumn = headername.ToString().Trim() == "Nationality" ? "NationalityPerICBS" : headercolumn;
                            headercolumn = headername.ToString().Trim() == "Next Rate Review Date" ? "NextRateReviewDateExtractedPerFaMSAAFICBS" : headercolumn;
                            headercolumn = headername.ToString().Trim() == "Tax ID No." ? "TaxID" : headercolumn;
                            headercolumn = headername.ToString().Trim() == "Loan Purpose Code" ? "LoanPurposeCode" : headercolumn;
                            headercolumn = headername.ToString().Trim() == "Maturity Type Code" ? "MaturityTypeCode" : headercolumn;
                            headercolumn = headername.ToString().Trim() == "Bank Relationship" ? "BankRelationship" : headercolumn;
                            headercolumn = headername.ToString().Trim() == "Syndicated Loan Ind" ? "SyndicatedLoanInd" : headercolumn;
                            headercolumn = headername.ToString().Trim() == "Customer Type" ? "CustomerTypeDescription" : headercolumn;
                            headercolumn = headername.ToString().Trim() == "Dosri Tag" ? "RPT" : headercolumn;
                            headercolumn = headername.ToString().Trim() == "Collateral Code" ? "ICBSCollateralCode" : headercolumn;
                            headercolumn = headername.ToString().Trim() == "Collateral Value" ? "AssetValue" : headercolumn;
                            headercolumn = headername.ToString().Trim() == "Line Amount" ? "ApprovedAmount" : headercolumn;
                            headercolumn = headername.ToString().Trim() == "Last Principal Payment" ? "LastPrincipalPay" : headercolumn;
                            headercolumn = headername.ToString().Trim() == "LPP Date" ? "PrincipalPayDate" : headercolumn;
                            headercolumn = headername.ToString().Trim() == "Last Interest Payment" ? "LastInterestPay" : headercolumn;
                            headercolumn = headername.ToString().Trim() == "LIP Date" ? "LastInterestPayDate" : headercolumn;
                            #endregion

                            //Remove unwanted characters(Special Characters and whitespace) and convert into lowercase
                            var NewHeader = Regex.Replace(headercolumn, @"([^a-zA-Z0-9]|^\s)", string.Empty).ToLower();

                            dtIcbs.Columns.Add(NewHeader);
                        }
                    }

                    #region Add Column After reading the Raw File 

                    dtIcbs.Columns.Add("Collateral");
                    dtIcbs.Columns.Add("monthlyob");
                    dtIcbs.Columns.Add("system");
                    dtIcbs.Columns.Add("previousmonthsnpltaggingbyrisk");
                    dtIcbs.Columns.Add("specificrequiredprovisions");
                    dtIcbs.Columns.Add("generalrequiredprovisions");

                    dtIcbs.Columns.Add("RecordDate");
                    dtIcbs.Columns.Add("Reason");

                    dtIcbs.Columns.Add("ICBSGLCode");
                    dtIcbs.Columns.Add("ICBSGLName");

                    dtIcbs.Columns.Add("TranNo");
                    dtIcbs.Columns.Add("RawFiles");
                    dtIcbs.Columns.Add("isDeleted");
                    dtIcbs.Columns.Add("UserName");
                    dtIcbs.Columns.Add("TransDate");
                    dtIcbs.Columns.Add("isConsolidated");
                    #endregion


                    var rowsCount = 0;
                    while (!sr.EndOfStream)
                    {
                        // Thread.Sleep(1);//Add 1 millisecond delay to see the actual process on the view

                        rowsCount++;
                        string[] cols = sr.ReadLine().Split('|');
                        DataRow dr = dtIcbs.NewRow();

                        curRow = rowsCount;

                        for (int i = 0; i < headers.Length; i++)
                        {
                            //Thread.Sleep(1);

                            icbsmodel = new AAFModel();

                            progressArray[0] = (i * 100 / headers.Length).ToString(); // percent
                            progressArray[1] = "Reading ICBS RAW Files, Please wait..."; //header text
                            progressArray[2] = "Validating Columns, Please wait..."; //Status
                            progressArray[3] = i.ToString(); //column
                            progressArray[4] = headers.Length.ToString(); //total column

                            var value = cols[i];


                            var AsOfDate = Convert.ToDateTime(cols[1]).ToShortDateString().ToString();

                            if (!isValidDate(AsOfDate))
                            {
                                if (icbsWorker.IsBusy)
                                {
                                    _InValidDate = true;
                                    e.Cancel = true;
                                    icbsWorker.CancelAsync();
                                }
                            }
                            else
                            {
                                ICBSDateParameter = AsOfDate;// Set the parameter value based on the icbs data
                            }

                            //pastduedateitldateextractedperaaficbs

                            //For Currency value
                            var _currencyType = cols[24];

                            //Check the Currency Type if 1 convert the amount into peso, NOTE: Browse the Exchange Rate maintenance to see the updated Rate value.

                            if (_currencyType == "1") //Convert Amount to peso if Currency is in Dollar
                            {
                                #region For Amount Finance Value OR Total Loan 
                                if (i == 17)
                                {
                                    var amountFinance = cols[i].ToString().Trim() == "" ? "0" : cols[i].ToString().Trim();
                                    dr[i] = ((GetOutputStramount(styles, amountFinance)) * currencyRate).ToString("#,0.00");//For Amount Finance Value OR Total Loan 

                                }
                                #endregion

                                #region For O/S Bal. (Orig) Value
                                else if (i == 18)
                                {
                                    var amountOSBAL = cols[i].ToString().Trim() == "" ? "0" : cols[i].ToString().Trim();
                                    dr[i] = ((GetOutputStramount(styles, amountOSBAL)) * currencyRate).ToString("#,0.00");//For O/S Bal. (Orig) Value
                                }
                                #endregion

                                #region For AIR (Orig) Value OR Accrued Interest Receivable
                                else if (i == 27)
                                {
                                    var amountAIR = cols[i].ToString().Trim() == "" ? "0" : cols[i].ToString().Trim();
                                    dr[i] = ((GetOutputStramount(styles, amountAIR)) * currencyRate).ToString("#,0.00");//For AIR (Orig) Value OR Accrued Interest Receivable
                                }                                                                   // }
                                #endregion

                                #region For Last Principal Payment Value
                                else if (i == 37)
                                {
                                    var amountLastPrincipal = cols[i].ToString().Trim() == "" ? "0" : cols[i].ToString().Trim();
                                    dr[i] = ((GetOutputStramount(styles, amountLastPrincipal)) * currencyRate).ToString("#,0.00");//For Last Principal Payment Value
                                }                                                                                //}
                                #endregion

                                #region For Last Interest Payment Value
                                else if (i == 39)
                                {
                                    var amountLastInterest = cols[i].ToString().Trim() == "" ? "0" : cols[i].ToString().Trim();
                                    dr[i] = ((GetOutputStramount(styles, amountLastInterest)) * currencyRate).ToString("#,0.00");//For Last Interest Payment Value
                                }
                                #endregion

                                #region For Collateral Value Value  OR Asset Value
                                else if (i == 65)
                                {
                                    var amountAssetValue = cols[i].ToString().Trim() == "" ? "0" : cols[i].ToString().Trim();
                                    dr[i] = ((GetOutputStramount(styles, amountAssetValue)) * currencyRate).ToString("#,0.00");//For Collateral Value Value  OR Asset Value
                                }
                                #endregion
                                else
                                {
                                    if (i == 31)
                                    {
                                        dr[i] = cols[i] + " & " + cols[32];
                                    }
                                    else
                                    {
                                        if (i == 8)
                                        {
                                            if (!isValidDate(cols[8].ToString()))
                                            {
                                                dr[i] = "01/01/1900";
                                            }
                                            else
                                            {
                                                dr[i] = Convert.ToDateTime(cols[i]).ToString("MM/dd/yyyy");
                                            }

                                        }
                                        else if (i == 9)
                                        {
                                            if (!isValidDate(cols[9].ToString()))
                                            {
                                                dr[i] = "01/01/1900";
                                            }
                                            else
                                            {
                                                dr[i] = Convert.ToDateTime(cols[i]).ToString("MM/dd/yyyy");
                                            }
                                        }
                                        else if (i == 10)
                                        {
                                            if (!isValidDate(cols[10].ToString()))
                                            {
                                                dr[i] = "01/01/1900";
                                            }
                                            else
                                            {
                                                dr[i] = Convert.ToDateTime(cols[i]).ToString("MM/dd/yyyy");
                                            }
                                        }
                                        else if (i == 38)
                                        {
                                            if (!isValidDate(cols[38].ToString()))
                                            {
                                                dr[i] = "01/01/1900";
                                            }
                                            else
                                            {
                                                dr[i] = Convert.ToDateTime(cols[i]).ToString("MM/dd/yyyy");
                                            }
                                        }
                                        else if (i == 40)
                                        {
                                            if (!isValidDate(cols[40].ToString()))
                                            {
                                                dr[i] = "01/01/1900";
                                            }
                                            else
                                            {
                                                dr[i] = Convert.ToDateTime(cols[i]).ToString("MM/dd/yyyy");
                                            }
                                        }
                                        else if (i == 60)
                                        {
                                            if (!isValidDate(cols[60].ToString()))
                                            {
                                                dr[i] = "01/01/1900";
                                            }
                                            else
                                            {
                                                dr[i] = Convert.ToDateTime(cols[i]).ToString("MM/dd/yyyy");
                                            }
                                        }
                                        else
                                        {
                                            dr[i] = cols[i];
                                        }
                                    }
                                }
                            }
                            else
                            {
                                if (i == 31)
                                {
                                    dr[i] = cols[i] + " & " + cols[32];
                                }
                                else
                                {
                                    if (i == 8)
                                    {
                                        if (!isValidDate(cols[8].ToString()))
                                        {
                                            dr[i] = "01/01/1900";
                                        }
                                        else
                                        {
                                            dr[i] = Convert.ToDateTime(cols[i]).ToString("MM/dd/yyyy");
                                        }

                                    }
                                    else if (i == 9)
                                    {
                                        if (!isValidDate(cols[9].ToString()))
                                        {
                                            dr[i] = "01/01/1900";
                                        }
                                        else
                                        {
                                            dr[i] = Convert.ToDateTime(cols[i]).ToString("MM/dd/yyyy");
                                        }
                                    }
                                    else if (i == 10)
                                    {
                                        if (!isValidDate(cols[10].ToString()))
                                        {
                                            dr[i] = "01/01/1900";
                                        }
                                        else
                                        {
                                            dr[i] = Convert.ToDateTime(cols[i]).ToString("MM/dd/yyyy");
                                        }
                                    }
                                    else if (i == 38)
                                    {
                                        if (!isValidDate(cols[38].ToString()))
                                        {
                                            dr[i] = "01/01/1900";
                                        }
                                        else
                                        {
                                            dr[i] = Convert.ToDateTime(cols[i]).ToString("MM/dd/yyyy");
                                        }
                                    }
                                    else if (i == 40)
                                    {
                                        if (!isValidDate(cols[40].ToString()))
                                        {
                                            dr[i] = "01/01/1900";
                                        }
                                        else
                                        {
                                            dr[i] = Convert.ToDateTime(cols[i]).ToString("MM/dd/yyyy");
                                        }
                                    }
                                    else if (i == 60)
                                    {
                                        if (!isValidDate(cols[60].ToString()))
                                        {
                                            dr[i] = "01/01/1900";
                                        }
                                        else
                                        {
                                            dr[i] = Convert.ToDateTime(cols[i]).ToString("MM/dd/yyyy");
                                        }
                                    }
                                    else
                                    {
                                        dr[i] = cols[i];
                                    }
                                }
                            }

                            if (!isICBSExist)
                            {
                                //var resultConso = consolidatorRepository.ConsoChecker(ICBSDateParameter);
                                var parameter = DateTime.Today;
                                var firstDayOfMonth = new DateTime(parameter.Year, parameter.Month, 1);
                                var resultConso = Convert.ToDateTime(ICBSDateParameter) < firstDayOfMonth;
                                if (icbsWorker.IsBusy && resultConso)
                                {
                                    isPreviousData = true;
                                    e.Cancel = true;
                                    icbsWorker.CancelAsync();
                                }
                                isICBSExist = true;
                            }

                            icbsWorker.ReportProgress(iCounter++ * 100 / lineCount, progressArray);
                        }

                        dtIcbs.Rows.Add(dr);
                        icbsWorker.ReportProgress(iCounter++ * 100 / lineCount, progressArray);
                    }

                    for (int i = 0; i < dtIcbs.Rows.Count; i++)
                    {
                        var valueToCopy = dtIcbs.Rows[i]["ob"].ToString();
                        var valueToCopyCollateral = dtIcbs.Rows[i]["ICBSCollateralCode"].ToString();
                        dtIcbs.Rows[i]["monthlyob"] = valueToCopy;//Duplication the OB column, and put into Monthly OB
                        dtIcbs.Rows[i]["system"] = "ICBS";//Used for System Tagging
                        dtIcbs.Rows[i]["previousmonthsnpltaggingbyrisk"] = "";//For the Future purpose
                        dtIcbs.Rows[i]["specificrequiredprovisions"] = "";//For the Future purpose
                        dtIcbs.Rows[i]["generalrequiredprovisions"] = "";//For the Future purpose
                        dtIcbs.Rows[i]["RecordDate"] = Convert.ToDateTime(ICBSDateParameter);//from the date of the files
                        dtIcbs.Rows[i]["Reason"] = "";//add reason for changes
                        dtIcbs.Rows[i]["Collateral"] = valueToCopyCollateral;//same as Collateral code
                                                                             // dtIcbs.Rows[i]["TranNo"] = TransNo;//this will be the sequential number, By default is 1
                        dtIcbs.Rows[i]["RawFiles"] = icbsFileName;//save the failename of the files, use to validate if the current file was already inserted in the database
                        dtIcbs.Rows[i]["isDeleted"] = false;//tagging for soft delete
                        dtIcbs.Rows[i]["UserName"] = UserName;//current user logged
                        dtIcbs.Rows[i]["TransDate"] = DateTime.Now.ToShortDateString();//date inserted
                        dtIcbs.Rows[i]["isConsolidated"] = true;//For the Future purpose

                        var _productdescription = dtIcbs.Rows[i]["facilitycode"].ToString().ToUpper().Trim();
                        var _statuscode = dtIcbs.Rows[i]["statuspersystem"].ToString().ToUpper().Trim();

                        //Override the value if item exists from dtGLCODE
                        for (int j = 0; j < dtGLCODE.Rows.Count; j++)
                        {
                            var system = dtGLCODE.Rows[j]["System"].ToString().ToUpper().Trim();
                            var facilitycode = dtGLCODE.Rows[j]["ProductDesc"].ToString().ToUpper().Trim();
                            var glstatus = dtGLCODE.Rows[j]["Status"].ToString().ToUpper().Trim();

                            var gmact = dtGLCODE.Rows[j]["GLCode"].ToString();
                            var gmname = dtGLCODE.Rows[j]["GLName"].ToString();

                            if (facilitycode == _productdescription && glstatus == _statuscode && system == "ICBS")
                            {
                                dtIcbs.Rows[i]["ICBSGLCode"] = gmact;
                                dtIcbs.Rows[i]["ICBSGLName"] = gmname;
                                break;
                            }
                        }

                    }

                    #region Eliminate Unwanted Columns
                    if (dtcompare.Columns.Count > 0)
                    {
                        List<DataColumn> columnsToDelete = new List<DataColumn>();
                        foreach (DataColumn col in dtIcbs.Columns)
                        {
                            if (!dtcompare.Columns.Contains(col.ColumnName))
                                columnsToDelete.Add(col);
                        }

                        foreach (DataColumn col in columnsToDelete)
                            dtIcbs.Columns.Remove(col);
                    }
                    #endregion
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error encountered while reading the file, Please contact your system administrator");
            }
            #endregion
        }
        #endregion

        #region AAF Worker
        private void aafWorker_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            string[] labelsreports = (string[])e.UserState;

            lblWaitInfo.Text = labelsreports[1];
            lblWaitStatus.Text = string.Format("Status: Reading at row {0} out of {1}", curRow, lineCount);
        }

        private void aafWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (e.Cancelled)
            {
                pnlWaitInfo.Visible = false;
                lblWaitInfo.Text = "";
                lblWaitStatus.Text = "Status: Error";

                isICBSExist = false;
                isAAFExist = false;
                isFAMSExist = false;

                if (isPreviousData)
                {
                    MetroMessageBox.Show(this, "\r\nSorry! System will not allow the user to insert a record from previous Months or Year.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }
                if (_InValidDate)
                {
                    MetroMessageBox.Show(this, "\r\nAAF Raw File date is Invalid Date.", "Invalid Date", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }
                else
                {
                    MetroMessageBox.Show(this, "\r\nOop! Something went wrong and couldn't process your request.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }
                dtAaf = new DataTable("AAFDATA");//Initialize again the datatable to avoid Error
            }
            else if (e.Error != null)
            {
                if (e.ToString().Contains("It is already opened exclusively by another user"))
                {
                    MetroMessageBox.Show(this, "\r\nICBS RAW File is already opened exclusively by another user, or you need permission to view and write its data.\r\nNOTE: Please Close or Save all Open Documents", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }
                else
                {
                    MetroMessageBox.Show(this, "\r\n\r\nError encountered while reading the file, Please contact your system administrator", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }
                
                lblWaitStatus.Text = "Status: Error Encountered while processing";
                dtAaf = new DataTable("AAFDATA");
                return;
            }
            else
            {
                lblWaitInfo.Text = "Initializing, Please wait...";
                lblWaitStatus.Text = "Status: Initializing...";
                //progressConso.Value = 100;
                //lblPercent.Text = 100 + " %";
                lblBusy.Text = "";
                lblWaitStatus.Text = string.Format("Status: Completed");
                Thread.Sleep(500);

                if (isFAMSReadyToProcess)
                {
                    progressArray = new string[5];
                    lineCount = 0;
                    FaMSDataTable();
                    lblWaitInfo.Text = "Fetching Data from FaMS Raw file, Please wait...";
                    lblWaitStatus.Text = "Status: Processing...";

                    famsWorker = new BackgroundWorker();
                    famsWorker.WorkerReportsProgress = true;
                    famsWorker.DoWork += new DoWorkEventHandler(famsWorker_DoWork);
                    famsWorker.RunWorkerCompleted += new RunWorkerCompletedEventHandler(famsWorker_RunWorkerCompleted);
                    famsWorker.ProgressChanged += new ProgressChangedEventHandler(famsWorker_ProgressChanged);
                    famsWorker.WorkerSupportsCancellation = true;
                    famsWorker.RunWorkerAsync();
                }
            }


            
        }

        private void aafWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            #region For AAF
            IsBusy = true;
            // Create the connection object 

            try
            {
                string connString = string.Format("Provider=Microsoft.Jet.OLEDB.4.0;Data Source={0};Extended Properties='Excel 8.0;HDR=no;IMEX=1;'", _AafPath);
                aafFileName = Path.GetFileName(_AafPath);
                using (OleDbConnection conn = new OleDbConnection(connString))
                {
                    conn.Open();
                    OleDbCommand cmd = new OleDbCommand();
                    DataTable dbSchema = conn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                    if (dbSchema == null || dbSchema.Rows.Count < 1)
                    {
                        throw new Exception("Error: Could not determined the name of the worksheet.");
                    }

                    string worksheetname = dbSchema.Rows[0]["TABLE_NAME"].ToString();

                    OleDbDataAdapter da = new OleDbDataAdapter("SELECT * FROM [" + worksheetname + "] WHERE[F1] <> ''", conn);

                    DataTable dtold = new DataTable(worksheetname);

                    da.Fill(dtold);

                    var AsOfDate = String.Format("{0:d}", Convert.ToDateTime(dtold.Rows[0][0].ToString().Substring(61)));
                    if (!isValidDate(AsOfDate))
                    {
                        if (aafWorker.IsBusy)
                        {
                            _InValidDate = true;
                            e.Cancel = true;
                            aafWorker.CancelAsync();
                        }
                    }
                    else
                    {
                        AAFDateParameter = AsOfDate; //Get As Of DATE of generated File
                    }

                    try
                    {

                        DataRow delrow = dtold.Rows[0];
                        delrow.Delete();
                        delrow.AcceptChanges();
                        int icount = dtold.Rows.Count;
                        DataRow delrow1 = dtold.Rows[icount - 1];
                        delrow1.Delete();
                        delrow1.AcceptChanges();

                        //Convert Row 3 value as a header of the DataTable
                        foreach (DataColumn dc in dtold.Columns)
                        {
                            dc.ColumnName = dtold.Rows[0][dc].ToString();
                        }

                        DataRow delrow2 = dtold.Rows[0];
                        delrow2.Delete();
                        delrow2.AcceptChanges();

                        lineCount = dtold.Rows.Count;

                        var irowCount = 0;
                        DataRow dr = null;
                        foreach (var item in dtold.Rows)
                        {
                            if (dtold.Rows[irowCount]["AccountNo"].ToString().Contains("ver")) break;

                            progressArray[0] = (irowCount * 100 / lineCount).ToString(); // percent
                            progressArray[1] = "Reading AAF RAW File, Please wait..."; //header text
                            progressArray[2] = "Validating Columns, Please wait..."; //Status
                            progressArray[3] = curRow.ToString(); //column
                            progressArray[4] = "0";// dtold.Columns.Count;// headers.Length.ToString(); //total column

                            // Thread.Sleep(1); //delay 

                            //Start from row 4 and column 0
                            if (!string.IsNullOrEmpty(dtold.Rows[irowCount]["AccountNo"].ToString()))
                            {
                                dr = dtAaf.NewRow();

                                var _currencyType = dtold.Rows[irowCount]["Currency"].ToString();

                                #region MyRegion
                                if (_currencyType.ToLower() == "usd")
                                {
                                    var amountTotalLoan = dtold.Rows[irowCount]["Total Loan"].ToString().Trim() == "" ? "0" : dtold.Rows[irowCount]["Total Loan"].ToString().Trim();
                                    dr["TotalLoan"] = ((GetOutputStramount(styles, amountTotalLoan)) * currencyRate).ToString("#,0.00");

                                    var amountOB = dtold.Rows[irowCount]["OB"].ToString().Trim() == "" ? "0" : dtold.Rows[irowCount]["OB"].ToString().Trim();
                                    dr["OB"] = ((GetOutputStramount(styles, amountOB)) * currencyRate).ToString("#,0.00");

                                    var amountMonthlyOB = dtold.Rows[irowCount]["Monthly OB"].ToString().Trim() == "" ? "0" : dtold.Rows[irowCount]["Monthly OB"].ToString().Trim();
                                    dr["MonthlyOB"] = ((GetOutputStramount(styles, amountMonthlyOB)) * currencyRate).ToString("#,0.00");

                                    var amountUDIBalance = dtold.Rows[irowCount]["UDI Balance"].ToString().Trim() == "" ? "0" : dtold.Rows[irowCount]["UDI Balance"].ToString().Trim();
                                    dr["UDIBalance"] = ((GetOutputStramount(styles, amountUDIBalance)) * currencyRate).ToString("#,0.00");

                                    var amountOrigERV = dtold.Rows[irowCount]["Orig ERV"].ToString().Trim() == "" ? "0" : dtold.Rows[irowCount]["Orig ERV"].ToString().Trim();
                                    dr["OrigERV"] = ((GetOutputStramount(styles, amountOrigERV)) * currencyRate).ToString("#,0.00");

                                    var amountPVRV = dtold.Rows[irowCount]["PVRV"].ToString().Trim() == "" ? "0" : dtold.Rows[irowCount]["PVRV"].ToString().Trim();
                                    dr["PVRV"] = ((GetOutputStramount(styles, amountPVRV)) * currencyRate).ToString("#,0.00");

                                    var amountOrigGD = dtold.Rows[irowCount]["Orig GD"].ToString().Trim() == "" ? "0" : dtold.Rows[irowCount]["Orig GD"].ToString().Trim();
                                    dr["OrigGD"] = ((GetOutputStramount(styles, amountOrigGD)) * currencyRate).ToString("#,0.00");

                                    var amountPVGD = dtold.Rows[irowCount]["PVGD"].ToString().Trim() == "" ? "0" : dtold.Rows[irowCount]["PVGD"].ToString().Trim();
                                    dr["PVGD"] = ((GetOutputStramount(styles, amountPVGD)) * currencyRate).ToString("#,0.00");

                                    var amountOriginalAmortizationAAF = dtold.Rows[irowCount]["Orig Amort."].ToString().Trim() == "" ? "0" : dtold.Rows[irowCount]["Orig Amort."].ToString().Trim();
                                    dr["OriginalAmortizationAAF"] = ((GetOutputStramount(styles, amountOriginalAmortizationAAF)) * currencyRate).ToString("#,0.00");

                                    var amountPaymentScheduleAmortizationAAF = dtold.Rows[irowCount]["Amort. Per Pay Sched."].ToString().Trim() == "" ? "0" : dtold.Rows[irowCount]["Amort. Per Pay Sched."].ToString().Trim();
                                    dr["PaymentScheduleAmortizationAAF"] = ((GetOutputStramount(styles, amountPaymentScheduleAmortizationAAF)) * currencyRate).ToString("#,0.00");

                                    var amountRepricedAmortization = dtold.Rows[irowCount]["Reprice Amort."].ToString().Trim() == "" ? "0" : dtold.Rows[irowCount]["Reprice Amort."].ToString().Trim();
                                    dr["RepricedAmortization"] = ((GetOutputStramount(styles, amountRepricedAmortization)) * currencyRate).ToString("#,0.00");

                                    var amountASSETCOST = dtold.Rows[irowCount]["Asset Cost"].ToString().Trim() == "" ? "0" : dtold.Rows[irowCount]["Asset Cost"].ToString().Trim();
                                    dr["ASSETCOST"] = ((GetOutputStramount(styles, amountASSETCOST)) * currencyRate).ToString("#,0.00");

                                    var amountAssetValue = dtold.Rows[irowCount]["Asset Value"].ToString().Trim() == "" ? "0" : dtold.Rows[irowCount]["Asset Value"].ToString().Trim();
                                    dr["AssetValue"] = ((GetOutputStramount(styles, amountAssetValue)) * currencyRate).ToString("#,0.00");

                                    var amountApprovedAmount = dtold.Rows[irowCount]["Approved Amount"].ToString().Trim() == "" ? "0" : dtold.Rows[irowCount]["Approved Amount"].ToString().Trim();
                                    dr["ApprovedAmount"] = ((GetOutputStramount(styles, amountApprovedAmount)) * currencyRate).ToString("#,0.00");

                                    var amountLastPrincipalPay = dtold.Rows[irowCount]["LastPrincipalPay"].ToString().Trim() == "" ? "0" : dtold.Rows[irowCount]["LastPrincipalPay"].ToString().Trim();
                                    dr["LastPrincipalPay"] = ((GetOutputStramount(styles, amountLastPrincipalPay)) * currencyRate).ToString("#,0.00");

                                    var amountLastInterestPay = dtold.Rows[irowCount]["LastInterestPay"].ToString().Trim() == "" ? "0" : dtold.Rows[irowCount]["LastInterestPay"].ToString().Trim();
                                    dr["LastInterestPay"] = ((GetOutputStramount(styles, amountLastInterestPay)) * currencyRate).ToString("#,0.00");
                                }
                                else
                                {
                                    dr["TotalLoan"] = dtold.Rows[irowCount]["Total Loan"];
                                    dr["OB"] = dtold.Rows[irowCount]["OB"];
                                    dr["MonthlyOB"] = dtold.Rows[irowCount]["Monthly OB"];
                                    dr["UDIBalance"] = dtold.Rows[irowCount]["UDI Balance"];
                                    dr["OrigERV"] = dtold.Rows[irowCount]["Orig ERV"];
                                    dr["PVRV"] = dtold.Rows[irowCount]["PVRV"];
                                    dr["OrigGD"] = dtold.Rows[irowCount]["Orig GD"];
                                    dr["PVGD"] = dtold.Rows[irowCount]["PVGD"];
                                    dr["OriginalAmortizationAAF"] = dtold.Rows[irowCount]["Orig Amort."];
                                    dr["PaymentScheduleAmortizationAAF"] = dtold.Rows[irowCount]["Amort. Per Pay Sched."];
                                    dr["RepricedAmortization"] = dtold.Rows[irowCount]["Reprice Amort."];
                                    dr["ASSETCOST"] = dtold.Rows[irowCount]["Asset Cost"];
                                    dr["AssetValue"] = dtold.Rows[irowCount]["Asset Value"];
                                    dr["ApprovedAmount"] = dtold.Rows[irowCount]["Approved Amount"];
                                    dr["LastPrincipalPay"] = dtold.Rows[irowCount]["LastPrincipalPay"];
                                    dr["LastInterestPay"] = dtold.Rows[irowCount]["LastInterestPay"];
                                }

                                dr["AccountNo"] = dtold.Rows[irowCount]["AccountNo"];
                                dr["ClientName"] = dtold.Rows[irowCount]["Client Name"];
                                dr["AO"] = dtold.Rows[irowCount]["AO"];
                                dr["FacilityCode"] = dtold.Rows[irowCount]["Prod Type"];
                                dr["StatusPERSYSTEM"] = dtold.Rows[irowCount]["Status"];

                                if (!isValidDate(dtold.Rows[irowCount]["Value Date"].ToString()))
                                {
                                    dr["ValueDate"] = "01/01/1900";
                                }
                                else
                                {
                                    dr["ValueDate"] = dtold.Rows[irowCount]["Value Date"].ToString();
                                }

                                if (!isValidDate(dtold.Rows[irowCount]["FirstDueDate"].ToString()))
                                {
                                    dr["FirstDueDate"] = "01/01/1900";
                                }
                                else
                                {
                                    dr["FirstDueDate"] = dtold.Rows[irowCount]["FirstDueDate"].ToString();
                                }

                                if (!isValidDate(dtold.Rows[irowCount]["Maturity Date"].ToString()))
                                {
                                    dr["MaturityDate"] = "01/01/1900";
                                }
                                else
                                {
                                    dr["MaturityDate"] = dtold.Rows[irowCount]["Maturity Date"].ToString();
                                }

                                dr["OriginalRate"] = dtold.Rows[irowCount]["Effective Rate"];
                                dr["CurrentRate"] = dtold.Rows[irowCount]["EYAfterReprice"];
                                dr["TermInmonths"] = dtold.Rows[irowCount]["Term"].ToString();
                                dr["RemainingTermInMonths"] = dtold.Rows[irowCount]["Remaining Term"];

                                if (!isValidDate(dtold.Rows[irowCount]["Reprice Date"].ToString()))
                                {
                                    dr["RepricedDate"] = "01/01/1900";
                                }
                                else
                                {
                                    dr["RepricedDate"] = dtold.Rows[irowCount]["Reprice Date"].ToString();
                                }

                                dr["AAFICBSRateType"] = dtold.Rows[irowCount]["Rate Type"];
                                var pduedate = dtold.Rows[irowCount]["PastDueDate"].ToString() != "" ? dtold.Rows[irowCount]["PastDueDate"].ToString() : "01/01/1900";
                                var itldate = dtold.Rows[irowCount]["ITL Date"].ToString() != "" ? dtold.Rows[irowCount]["ITL Date"].ToString() : "01/01/1900";
                                dr["PastDueDateITLDateExtractedPerAAFICBS"] = pduedate + " & " + itldate;
                                dr["PerFaMSAAFICBSIndustryCode"] = dtold.Rows[irowCount]["Industry Code"];
                                dr["IndustryHeader"] = dtold.Rows[irowCount]["Industry Detail"];
                                dr["IndustryDetail"] = dtold.Rows[irowCount]["Industry Detail"];
                                dr["Collateral"] = dtold.Rows[irowCount]["Collateral"];
                                dr["PerFaMSAAFICBSAssetSizeInwords"] = dtold.Rows[irowCount]["Asset Size"];
                                dr["ICBSGLCODE"] = dtold.Rows[irowCount]["GL Code"];
                                dr["ICBSGLName"] = dtold.Rows[irowCount]["GL Desc"];
                                dr["COSTCENTER"] = dtold.Rows[irowCount]["Cost Center"];
                                dr["BRANCHNAMEOFCOSTCENTERPERSYSTEM"] = dtold.Rows[irowCount]["Branch Per Cost Center"];
                                dr["OriginatingBranchBooked"] = dtold.Rows[irowCount]["Orig. Branch"];
                                dr["NationalityPerICBS"] = dtold.Rows[irowCount]["Nationality"];

                                if (!isValidDate(dtold.Rows[irowCount]["Next Review Date"].ToString()))
                                {
                                    dr["NextRateReviewDateExtractedPerFaMSAAFICBS"] = "01/01/1900";
                                }
                                else
                                {
                                    dr["NextRateReviewDateExtractedPerFaMSAAFICBS"] = dtold.Rows[irowCount]["Next Review Date"].ToString();
                                }

                                dr["TAXID"] = dtold.Rows[irowCount]["Tax ID"];
                                dr["CustomerTypeDescription"] = dtold.Rows[irowCount]["Borrower Type"];
                                dr["RELCode"] = dtold.Rows[irowCount]["REL Code"];
                                dr["REECode"] = dtold.Rows[irowCount]["REE Code"];
                                dr["REEAddtlInfo"] = dtold.Rows[irowCount]["REEAddtl.Info"];
                                dr["AcctRef"] = dtold.Rows[irowCount]["Acct. Ref."];
                                dr["RPT"] = dtold.Rows[irowCount]["RPT"];
                                dr["LeaseType"] = dtold.Rows[irowCount]["Lease Type"];
                                dr["ICBSCollateralCode"] = dtold.Rows[irowCount]["ICBS Collateral Code"];
                                dr["CPNumber"] = dtold.Rows[irowCount]["CP Number"];

                                if (!isValidDate(dtold.Rows[irowCount]["Principal Pay Date"].ToString()))
                                {
                                    dr["PrincipalPayDate"] = "01/01/1900";
                                }
                                else
                                {
                                    dr["PrincipalPayDate"] = dtold.Rows[irowCount]["Principal Pay Date"].ToString();
                                }

                                if (!isValidDate(dtold.Rows[irowCount]["Last Interest Pay Date"].ToString()))
                                {
                                    dr["LastInterestPayDate"] = "01/01/1900";
                                }
                                else
                                {
                                    dr["LastInterestPayDate"] = dtold.Rows[irowCount]["Last Interest Pay Date"].ToString();
                                }

                                dtAaf.Rows.Add(dr);
                                #endregion
                            }

                            if (!isAAFExist)
                            {
                                //var resultConso = consolidatorRepository.ConsoChecker(AAFDateParameter);
                                var parameter = DateTime.Today;
                                var firstDayOfMonth = new DateTime(parameter.Year, parameter.Month, 1);
                                var resultConso = Convert.ToDateTime(AAFDateParameter) < firstDayOfMonth;
                                if (aafWorker.IsBusy && resultConso)
                                {
                                    isPreviousData = true;
                                    e.Cancel = true;
                                    aafWorker.CancelAsync();
                                }
                                isAAFExist = true;
                            }

                            curRow++;
                            aafWorker.ReportProgress(irowCount++ * 100 / lineCount, progressArray);

                        }

                        dtAaf.Columns.Add("RecordDate");
                        dtAaf.Columns.Add("Reason");
                        dtAaf.Columns.Add("RawFiles");
                        dtAaf.Columns.Add("isDeleted");
                        dtAaf.Columns.Add("UserName");
                        dtAaf.Columns.Add("TransDate");
                        dtAaf.Columns.Add("isConsolidated");
                        //dtAaf.Columns.Add("SYSTEM");
                        //dtAaf.Columns.Add("PreviousMonthsNPLTaggingByRisk");
                        //dtAaf.Columns.Add("SpecificRequiredProvisions");
                        //dtAaf.Columns.Add("GeneralRequiredProvisions");

                        for (int i = 0; i < dtAaf.Rows.Count; i++)
                        {
                            dtAaf.Rows[i]["RecordDate"] = Convert.ToDateTime(AAFDateParameter);//from the date of the files
                            dtAaf.Rows[i]["Reason"] = "";//add reason for changes
                            dtAaf.Rows[i]["RawFiles"] = aafFileName;//save the failename of the files, use to validate if the current file was already inserted in the database
                            dtAaf.Rows[i]["isDeleted"] = false;//tagging for soft delete
                            dtAaf.Rows[i]["UserName"] = UserName;//current user logged
                            dtAaf.Rows[i]["TransDate"] = DateTime.Now.ToShortDateString();//date inserted
                            dtAaf.Rows[i]["isConsolidated"] = true;//For the Future purpose
                            dtAaf.Rows[i]["SYSTEM"] = "AAF";
                            dtAaf.Rows[i]["PreviousMonthsNPLTaggingByRisk"] = "";
                            dtAaf.Rows[i]["SpecificRequiredProvisions"] = "";
                            dtAaf.Rows[i]["GeneralRequiredProvisions"] = "";

                            var _productdescription = dtAaf.Rows[i]["facilitycode"].ToString().ToUpper().Trim();
                            var _statuscode = dtAaf.Rows[i]["statuspersystem"].ToString().ToUpper().Trim();

                            //Override the value if item exists from dtGLCODE
                            for (int j = 0; j < dtGLCODE.Rows.Count; j++)
                            {
                                var system = dtGLCODE.Rows[j]["System"].ToString().ToUpper().Trim();
                                var facilitycode = dtGLCODE.Rows[j]["ProductDesc"].ToString().ToUpper().Trim();
                                var glstatus = dtGLCODE.Rows[j]["Status"].ToString().ToUpper().Trim();

                                var gmact = dtGLCODE.Rows[j]["GLCode"].ToString().Trim();
                                var gmname = dtGLCODE.Rows[j]["GLName"].ToString().Trim();

                                if (facilitycode == _productdescription && glstatus == _statuscode && system == "AAF")
                                {
                                    dtAaf.Rows[i]["ICBSGLCode"] = gmact;
                                    dtAaf.Rows[i]["ICBSGLName"] = gmname;
                                    break;
                                }
                            }

                        }

                    }
                    catch (Exception ex)
                    {
                        // var sdfsdf = irowCount;
                        throw new Exception(ex.Message);
                    }
                }

                //lineCount = File.ReadAllLines(_AafPath).Length;
                //lblWaitFilePath.Text = _AafPath;
                //lblWaitStatus1.Text = string.Format("Total numbers of records: {0}", lineCount);

            }
            catch (Exception ex)
            {
                throw new Exception("Error encountered while reading the file, Please contact your system administrator");
            }
            #endregion
        }
        #endregion

        #region FAMS Worker

        private void famsWorker_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            string[] labelsreports = (string[])e.UserState;

            lblWaitInfo.Text = labelsreports[1];
            lblWaitStatus.Text = string.Format("Status: Reading at row {0} out of {1}", curRow, lineCount);
        }

        private void famsWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (e.Cancelled)
            {
                pnlWaitInfo.Visible = false;
                lblWaitInfo.Text = "";
                lblWaitStatus.Text = "Status: Error";

                isICBSExist = false;
                isAAFExist = false;
                isFAMSExist = false;

                if (isPreviousData)
                {
                    MetroMessageBox.Show(this, "\r\nSorry! System will not allow the user to insert a record from previous Months or Year.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }
                if (_InValidDate)
                {
                    MetroMessageBox.Show(this, "\r\nFAMS Raw File date is Invalid Date.", "Invalid Date", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }
                else
                {
                    MetroMessageBox.Show(this, "\r\nOop! Something went wrong and couldn't process your request.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }

                dtFams = new DataTable("FAMSDATA");//Initialize again the datatable to avoid Error
            }
            else if (e.Error != null)
            {
                if (e.ToString().Contains("It is already opened exclusively by another user"))
                {
                    MetroMessageBox.Show(this, "\r\nFaMS RAW File is already opened exclusively by another user, or you need permission to view and write its data.\r\nNOTE: Please Close or Save all Open Documents", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }
                else
                {
                    MetroMessageBox.Show(this, "\r\n\r\nError encountered while reading the file, Please contact your system administrator", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }

                lblWaitStatus.Text = "Status: Error Encountered while processing";
                dtFams = new DataTable("FAMSDATA");//Initialize again the datatable to avoid Error
                return;
            }
            else
            {
                lblWaitInfo.Text = "Consolidating the records, Please wait...";
                lblWaitStatus.Text = "Status: Processing...";
                lblBusy.Text = "";
                Thread.Sleep(100);

                progressArray = new string[5];
                lineCount = 0;
                lblWaitInfo.Text = "Inserting records to DataBase, Please wait...";
                lblWaitStatus.Text = "Status: Processing...";

                consolidateWorker = new BackgroundWorker();
                consolidateWorker.WorkerReportsProgress = true;
                consolidateWorker.WorkerSupportsCancellation = true;
                consolidateWorker.DoWork += new DoWorkEventHandler(consolidateWorker_DoWork);
                consolidateWorker.RunWorkerCompleted += new RunWorkerCompletedEventHandler(consolidateWorker_RunWorkerCompleted);
                consolidateWorker.ProgressChanged += new ProgressChangedEventHandler(consolidateWorker_ProgressChanged);
                consolidateWorker.RunWorkerAsync();

            }
        }

        private void famsWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            IsBusy = true;
            #region For Fams
            try
            {
                string connString = string.Format("Provider=Microsoft.Jet.OLEDB.4.0;Data Source={0};Extended Properties='Excel 8.0;HDR=yes;IMEX=1;'", _FamsPath);
                famsFileName = Path.GetFileName(_FamsPath);
                using (OleDbConnection conn = new OleDbConnection(connString))
                {
                    conn.Open();
                    OleDbCommand cmd = new OleDbCommand();
                    DataTable dbSchema = conn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                    if (dbSchema == null || dbSchema.Rows.Count < 1)
                    {
                        throw new Exception("Error: Could not determined the name of the worksheet.");
                    }

                    string worksheetname = dbSchema.Rows[0]["TABLE_NAME"].ToString();

                    OleDbDataAdapter da = new OleDbDataAdapter("SELECT * FROM [" + worksheetname + "] WHERE [BDO LEASING AND FINANCE, INC] <> ''", conn);

                    DataTable dtold = new DataTable(worksheetname);

                    da.Fill(dtold);

                    #region Remove Unwanted columns
                    dtold.Columns.Remove("F1");
                    dtold.Columns.Remove("F4");
                    dtold.Columns.Remove("F6");
                    dtold.Columns.Remove("F8");
                    dtold.Columns.Remove("F9");
                    dtold.Columns.Remove("F13");
                    dtold.Columns.Remove("F14");
                    dtold.Columns.Remove("F15");
                    dtold.Columns.Remove("F16");
                    dtold.Columns.Remove("F17");
                    dtold.Columns.Remove("F18");
                    dtold.Columns.Remove("F21");
                    dtold.Columns.Remove("F22");
                    dtold.Columns.Remove("F23");
                    dtold.Columns.Remove("F24");
                    dtold.Columns.Remove("F25");
                    dtold.Columns.Remove("F26");
                    dtold.Columns.Remove("F27");
                    dtold.Columns.Remove("F28");
                    dtold.Columns.Remove("F29");
                    dtold.Columns.Remove("F30");
                    dtold.Columns.Remove("F31");
                    dtold.Columns.Remove("F32");
                    dtold.Columns.Remove("F33");
                    dtold.Columns.Remove("F34");
                    dtold.Columns.Remove("F35");
                    dtold.Columns.Remove("F36");
                    dtold.Columns.Remove("F44");

                    #endregion

                    var AsOfDate = String.Format("{0:d}", Convert.ToDateTime(dtold.Rows[1][0].ToString()).ToShortDateString().ToString());

                    if (!isValidDate(AsOfDate))
                    {
                        if (famsWorker.IsBusy)
                        {
                            _InValidDate = true;
                            e.Cancel = true;
                            famsWorker.CancelAsync();
                        }
                    }
                    else
                    {
                        FAMSDateParameter = AsOfDate; //Get As Of DATE of generated File
                    }

                    try
                    {
                        DataRow delrow0 = dtold.Rows[0];
                        delrow0.Delete();
                        delrow0.AcceptChanges();
                        DataRow delrow1 = dtold.Rows[0];
                        delrow1.Delete();
                        delrow1.AcceptChanges();
                        DataRow delrow2 = dtold.Rows[0];
                        delrow2.Delete();
                        delrow2.AcceptChanges();


                        var startRow = 0;
                        DataRow dr = null;
                        //Convert Row 3 value as a header of the DataTable
                        foreach (DataColumn dc in dtold.Columns)
                        {
                            dc.ColumnName = dtold.Rows[0][dc].ToString();
                        }

                        DataRow delrow3 = dtold.Rows[0];
                        delrow3.Delete();
                        delrow3.AcceptChanges();

                        lineCount = dtold.Rows.Count;
                        var irowCount = 0;

                        foreach (DataRow row in dtold.Rows)
                        {
                            progressArray[0] = (irowCount * 100 / lineCount).ToString(); // percent
                            progressArray[1] = "Reading FaMS RAW File, Please wait..."; //header text
                            progressArray[2] = "Validating Columns, Please wait..."; //Status
                            progressArray[3] = "";// i.ToString(); //column
                            progressArray[4] = "0";// dtold.Columns.Count;// headers.Length.ToString(); //total column

                            var code = dtold.Rows[startRow].ItemArray[0].ToString().Trim();//"Receivables"

                            int _code = 0;
                            bool validCode = int.TryParse(code, out _code);

                            if (validCode)
                            {
                                var ReceivablesAmount = Convert.ToDouble(dtold.Rows[startRow].ItemArray[6]);//"Receivables"
                                var status = dtold.Rows[startRow].ItemArray[3].ToString();//["Status"].ToString();

                                if (ReceivablesAmount <= 0 || status == "PAST DUE" || string.IsNullOrEmpty(code))
                                {
                                    startRow++;
                                    continue;
                                }
                                else
                                {
                                    dr = dtFams.NewRow();

                                    dr["SYSTEM"] = "FAMS";
                                    dr["AccountNo"] = dtold.Rows[startRow]["Client Code"].ToString();
                                    dr["ClientName"] = dtold.Rows[startRow]["Client Name"].ToString();
                                    dr["AO"] = dtold.Rows[startRow]["Account Officer"].ToString();
                                    dr["StatusPERSYSTEM"] = dtold.Rows[startRow]["Status"].ToString();

                                    if (!isValidDate(dtold.Rows[startRow]["From"].ToString()))
                                    {
                                        dr["ValueDate"] = "01/01/1900";
                                    }
                                    else
                                    {
                                        dr["ValueDate"] = dtold.Rows[startRow]["From"].ToString();
                                    }

                                    if (!isValidDate(dtold.Rows[startRow]["To"].ToString()))
                                    {
                                        dr["MaturityDate"] = "01/01/1900";
                                    }
                                    else
                                    {
                                        dr["MaturityDate"] = dtold.Rows[startRow]["To"].ToString();
                                    }

                                    dr["TotalLoan"] = dtold.Rows[startRow]["Investment Limit"].ToString();
                                    dr["OB"] = dtold.Rows[startRow]["Receivables"].ToString();
                                    dr["MonthlyOB"] = dtold.Rows[startRow]["Receivables"].ToString();
                                    dr["ClientsEquity"] = dtold.Rows[startRow]["Client's Equity Of Unpaid Invoices"].ToString();
                                    dr["AccruedInterestReceivable"] = dtold.Rows[startRow]["Discount Charge - Accrual"].ToString();

                                    dr["OriginalRate"] = Convert.ToDouble(dtold.Rows[irowCount]["Current DC%"].ToString().Trim().Replace("%", "")); //dtold.Rows[startRow]["Current DC%"].ToString();
                                    dr["CurrentRate"] = Convert.ToDouble(dtold.Rows[irowCount]["Current DC%"].ToString().Trim().Replace("%", "")); //dtold.Rows[startRow]["Current DC%"].ToString();
                                    dr["TermInmonths"] = dtold.Rows[startRow]["Credit Term"].ToString();
                                    dr["PerFaMSAAFICBSIndustryCode"] = dtold.Rows[startRow]["Industry Code"].ToString();
                                    dr["IndustryHeader"] = dtold.Rows[startRow]["Industry Details / Description"].ToString();
                                    dr["IndustryDetail"] = dtold.Rows[startRow]["Industry Details / Description"].ToString();
                                    dr["PerFaMSAAFICBSAssetSizeInwords"] = dtold.Rows[startRow]["Size Of Firm / Asset Size"].ToString();

                                    if (!isValidDate(dtold.Rows[startRow]["To"].ToString()))
                                    {
                                        dr["NextRateReviewDateExtractedPerFaMSAAFICBS"] = "01/01/1900";
                                    }
                                    else
                                    {
                                        dr["NextRateReviewDateExtractedPerFaMSAAFICBS"] = dtold.Rows[startRow]["Review Date"].ToString();
                                    }

                                    dr["PreviousMonthsNPLTaggingByRisk"] = "";
                                    dr["SpecificRequiredProvisions"] = "";
                                    dr["GeneralRequiredProvisions"] = "";
                                    dr["RecordDate"] = Convert.ToDateTime(FAMSDateParameter);
                                    dr["Reason"] = "";
                                    dr["RawFiles"] = famsFileName;
                                    dr["isDeleted"] = false;
                                    dr["isConsolidated"] = true;
                                    dr["UserName"] = UserName;
                                    dr["TransDate"] = DateTime.Now.ToShortDateString();

                                    /*
                                    var _productdescription = dtold.Rows[startRow]["facilitycode"].ToString().ToUpper().Trim();
                                    var _statuscode = dtold.Rows[startRow]["statuspersystem"].ToString().ToUpper().Trim();

                                    //Override the value if item exists from dtGLCODE
                                    for (int j = 0; j < dtGLCODE.Rows.Count; j++)
                                    {
                                        var system = dtGLCODE.Rows[j]["System"].ToString().ToUpper().Trim();
                                        var facilitycode = dtGLCODE.Rows[j]["ProductDesc"].ToString().ToUpper().Trim();
                                        var glstatus = dtGLCODE.Rows[j]["Status"].ToString().ToUpper().Trim();

                                        var gmact = dtGLCODE.Rows[j]["GLCode"].ToString().Trim();
                                        var gmname = dtGLCODE.Rows[j]["GLName"].ToString().Trim();

                                        if (facilitycode == _productdescription && glstatus == _statuscode && system == "AAF")
                                        {
                                            dr["ICBSGLCode"] = gmact;
                                            dr["ICBSGLName"] = gmname;
                                            break;
                                        }
                                    }
                                    */

                                    if (!isFAMSExist)
                                    {
                                        // var resultConso = consolidatorRepository.ConsoChecker(FAMSDateParameter);
                                        var parameter = DateTime.Today;
                                        var firstDayOfMonth = new DateTime(parameter.Year, parameter.Month, 1);
                                        var resultConso = Convert.ToDateTime(FAMSDateParameter) < firstDayOfMonth;
                                        if (famsWorker.IsBusy && resultConso)
                                        {
                                            isPreviousData = true;
                                            e.Cancel = true;
                                            famsWorker.CancelAsync();
                                        }
                                        isFAMSExist = true;
                                    }

                                    famsWorker.ReportProgress(irowCount++ * 100 / lineCount, progressArray);

                                }

                                dtFams.Rows.Add(dr);

                                startRow++;
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        throw new Exception(ex.Message);
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error encountered while reading the file, Please contact your system administrator");
            }
            #endregion
        }

        #endregion

        #region Conso Worker

        private void consolidateWorker_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            string[] labelsreports = (string[])e.UserState;
            lblWaitInfo.Text = labelsreports[1];
            lblWaitStatus.Text = "In progress...";
        }

        private void consolidateWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (e.Cancelled)
            {
                pnlWaitInfo.Visible = false;
                lblWaitInfo.Text = "";
                lblWaitStatus.Text = "Status: Error";

                isICBSExist = false;
                isAAFExist = false;
                isFAMSExist = false;
                IsBusy = false;
                if (dateNotTheSame)
                {
                    MetroMessageBox.Show(this, "\r\nICBS, AAF and FaMS date should be the same.", "Fatal Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }
                if (isPreviousDate)
                {
                    MetroMessageBox.Show(this, "\r\nUnable to process the record from previous months.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }
                else
                {
                    MetroMessageBox.Show(this, "\r\nOop! Something went wrong and couldn't process your request.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }
                dtConso = new DataTable();//Initialize again the datatable to avoid Error
            }
            else if (e.Error != null)
            {
                lblWaitStatus.Text = "Status: Error Encountered while processing";
                dtConso = new DataTable();//Initialize again the datatable to avoid Error
                IsBusy = false;
                MetroMessageBox.Show(this, "\r\n\r\nError encountered while consolidating the file, Please contact your system administrator", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
               // MetroMessageBox.Show(this, "\r\n\r\nError encountered while reading the file, Please contact your system administrator", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return;
            }
            else
            {
                pnlWaitInfo.Visible = false;
                lblWaitInfo.Text = "DONE";
                lblWaitStatus.Text = "Status: Success";

                isICBSExist = false;
                isAAFExist = false;
                isFAMSExist = false;
                IsBusy = false;

                /*
                //================================================================

                //updateGLworker
                lblWaitInfo.Text = "Updating the GL Code and GL Description, Please wait...";
                lblWaitStatus.Text = "Status: Processing...";
                lblBusy.Text = "";
                Thread.Sleep(500);


                //lineCount = 0;
                //lblWaitInfo.Text = "Inserting records to DataBase, Please wait...";
                //lblWaitStatus.Text = "Status: Processing...";

                updateGLworker = new BackgroundWorker();
                updateGLworker.WorkerReportsProgress = true;
                updateGLworker.WorkerSupportsCancellation = true;
                updateGLworker.DoWork += new DoWorkEventHandler(updateGLworker_DoWork);
                updateGLworker.RunWorkerCompleted += new RunWorkerCompletedEventHandler(updateGLworker_RunWorkerCompleted);
                updateGLworker.ProgressChanged += new ProgressChangedEventHandler(updateGLworker_ProgressChanged);
                updateGLworker.RunWorkerAsync();


                //==========================================================================================
                */
                MetroMessageBox.Show(this, "\r\nData was successfully consolidated.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                //Thread.Sleep(200);
                GetConsolidator1();
            }
        }

        private void consolidateWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            try
            {
                var icbsparameter = Convert.ToDateTime(ICBSDateParameter);
                var aafparameter = Convert.ToDateTime(AAFDateParameter);
                var famsparameter = Convert.ToDateTime(FAMSDateParameter);
                var todate = DateTime.Today;

                var ifirstDayOfTheCurrentMonth = new DateTime(icbsparameter.Year, icbsparameter.Month, 1);
                var afirstDayOfTheCurrentMonth = new DateTime(aafparameter.Year, aafparameter.Month, 1);
                var ffirstDayOfTheCurrentMonth = new DateTime(famsparameter.Year, famsparameter.Month, 1);
                var istodate = new DateTime(todate.Year, todate.Month, 1);

                if ((ifirstDayOfTheCurrentMonth < istodate) || (afirstDayOfTheCurrentMonth < istodate) || (ffirstDayOfTheCurrentMonth < istodate))
                {
                    if (consolidateWorker.IsBusy)
                    {
                        isPreviousDate = true;
                        e.Cancel = true;
                        IsBusy = true;
                        consolidateWorker.CancelAsync();
                    }
                }

                if ((ICBSDateParameter != AAFDateParameter) || (FAMSDateParameter != AAFDateParameter))
                {
                    if (consolidateWorker.IsBusy)
                    {
                        dateNotTheSame = true;
                        e.Cancel = true;
                        IsBusy = true;
                        consolidateWorker.CancelAsync();
                    }
                }
                else
                {
                    if (!dateNotTheSame)
                    {
                        object[] data = { dtIcbs, dtAaf, dtFams };
                        consolidatorRepository.BulkInsert(data, ICBSDateParameter);
                    }
                }
            }
            //catch (Exception ex)
            //{
            //    throw ex;
            //}
            catch (DbEntityValidationException dbEx)
            {
                foreach (var validationErrors in dbEx.EntityValidationErrors)
                {
                    foreach (var validationError in validationErrors.ValidationErrors)
                    {
                        System.Console.WriteLine("Property: {0} Error: {1}", validationError.PropertyName, validationError.ErrorMessage);
                    }
                }
            }
        }
        #endregion

        #region Update GL
        private void updateGLworker_DoWork(object sender, DoWorkEventArgs e)
        {
            try
            {
                object[] data = { dtIcbs, dtAaf, dtFams };

                foreach (DataRow accno in dtIcbs.Rows)
                {
                    consolidatorRepository.isGLCodeExist(accno["AccountNo"].ToString());
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private void updateGLworker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (e.Cancelled)
            {
                pnlWaitInfo.Visible = false;
                lblWaitInfo.Text = "";
                lblWaitStatus.Text = "Status: Error";

                IsBusy = false;

                MetroMessageBox.Show(this, "\r\nOop! Something went wrong and couldn't process your request.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else if (e.Error != null)
            {
                lblWaitStatus.Text = "Status: Error Encountered while processing";
                IsBusy = false;

                MetroMessageBox.Show(this, "\r\n\r\nError encountered while consolidating the file, Please contact your system administrator", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return;
            }
            else
            {
                pnlWaitInfo.Visible = false;
                lblWaitInfo.Text = "DONE";
                lblWaitStatus.Text = "Status: Success";
                IsBusy = false;
                //================================================================

                //updateGLworker
                lblWaitInfo.Text = "Updating the GL Code and GL Description, Please wait...";
                lblWaitStatus.Text = "Status: Processing...";
                lblBusy.Text = "";
                Thread.Sleep(500);

                updateGLworker = new BackgroundWorker();
                updateGLworker.WorkerReportsProgress = true;
                updateGLworker.WorkerSupportsCancellation = true;
                updateGLworker.DoWork += new DoWorkEventHandler(updateGLworker_DoWork);
                updateGLworker.RunWorkerCompleted += new RunWorkerCompletedEventHandler(updateGLworker_RunWorkerCompleted);
                updateGLworker.ProgressChanged += new ProgressChangedEventHandler(updateGLworker_ProgressChanged);
                updateGLworker.RunWorkerAsync();

                //==========================================================================================
                MetroMessageBox.Show(this, "\r\nData was successfully consolidated.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                //Thread.Sleep(200);
                GetConsolidator1();
            }
        }

        private void updateGLworker_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            string[] labelsreports = (string[])e.UserState;
            lblWaitInfo.Text = labelsreports[1];
            lblWaitStatus.Text = "In progress...";
        }

        #endregion

        protected bool isValidDate(String date)
        {
            try
            {
                DateTime dt = DateTime.Parse(date);
                return true;
            }
            catch
            {
                return false;
            }
        }

        private void HideColumns()
        {
            dgvConsolidator.Columns["TransID"].Visible = false;
            dgvConsolidator.Columns["RawFiles"].Visible = false;
            dgvConsolidator.Columns["isConsolidated"].Visible = false;
            dgvConsolidator.Columns["isDeleted"].Visible = false;
            dgvConsolidator.Columns["UserName"].Visible = false;
            dgvConsolidator.Columns["TransDate"].Visible = false;
            dgvConsolidator.Columns["Reason"].Visible = false;
            dgvConsolidator.Columns["RecordDate"].Visible = false;
        }

        private void GetConsolidator()
        {
            pnlWaitInfo.Visible = true;
            lblWaitInfo.Text = "Please wait while loading records...";
            lblWaitStatus.Text = "Status: Fetching Data.";

            var query = consolidatorRepository.GetAll().ToList();
            source.DataSource = query;
            lblInfo.Text = "Total Records: " + query.ToList().Count.ToString();

            if (query.Count() <= 0)
            {
                var retval = GetColumnNames().ToList();

                dtTmp = retval.ToDataTable();
                dtcompare = dtTmp.ToLowerDataTable();

                dgvConsolidator.DataSource = dtTmp;
                HideColumns();
            }
            else
            {
                dgvConsolidator.DataSource = source;
                //dtConso = dgvConsolidator.DataSource;

                DataTable dt = new DataTable();
                dtConso = dgvConsolidator.DataGridViewToDataTable();

                HideColumns();
            }
            pnlWaitInfo.Visible = false;
        }

        private void GetConsolidator1()
        {
            //pnlWaitInfo.Visible = true;
            //lblWaitInfo.Text = "Please wait while loading records...";
            //lblWaitStatus.Text = "Status: Fetching Data.";

            var query = consolidatorRepository.GetAll().ToList();
            //source.DataSource = query;
            //lblInfo.Text = "Total Records: " + query.ToList().Count.ToString();

            //if (query.Count() <= 0)
            //{
            //    var retval = GetColumnNames().ToList();

            //    dtTmp = retval.ToDataTable();
            //    dtcompare = dtTmp.ToLowerDataTable();

            //    dgvConsolidator.DataSource = dtTmp;
            //    HideColumns();
            //}
            //else
            //{
            dgvConsolidator.DataSource = query;
            //dtConso = dgvConsolidator.DataSource;

            //DataTable dt = new DataTable();
            //dtConso = dgvConsolidator.DataGridViewToDataTable();

            // HideColumns();
            //}
            // pnlWaitInfo.Visible = false;
        }

        private DataTable FaMSDataTable()
        {
            dtFams = new DataTable("FAMSDATA");

            dtFams.Columns.Add("system");
            dtFams.Columns.Add("RecordDate");
            dtFams.Columns.Add("Reason");
            dtFams.Columns.Add("RawFiles");
            dtFams.Columns.Add("isDeleted");
            dtFams.Columns.Add("UserName");
            dtFams.Columns.Add("TransDate");
            dtFams.Columns.Add("isConsolidated");
            dtFams.Columns.Add("AccountNo");
            dtFams.Columns.Add("ClientName");
            dtFams.Columns.Add("AO");
            dtFams.Columns.Add("StatusPERSYSTEM");
            dtFams.Columns.Add("ValueDate");
            dtFams.Columns.Add("MaturityDate");
            dtFams.Columns.Add("TotalLoan");
            dtFams.Columns.Add("OB");
            dtFams.Columns.Add("MonthlyOB");
            dtFams.Columns.Add("ClientsEquity");
            dtFams.Columns.Add("AccruedInterestReceivable");
            dtFams.Columns.Add("OriginalRate");
            dtFams.Columns.Add("CurrentRate");
            dtFams.Columns.Add("TermInmonths");
            dtFams.Columns.Add("PerFaMSAAFICBSIndustryCode");
            dtFams.Columns.Add("IndustryHeader");
            dtFams.Columns.Add("IndustryDetail");
            dtFams.Columns.Add("PerFaMSAAFICBSAssetSizeInwords");
            dtFams.Columns.Add("NextRateReviewDateExtractedPerFaMSAAFICBS");
            dtFams.Columns.Add("PreviousMonthsNPLTaggingByRisk");
            dtFams.Columns.Add("SpecificRequiredProvisions");
            dtFams.Columns.Add("GeneralRequiredProvisions");
            // dtFams.Columns.Add("GeneralRequiredProvisions");
            return dtFams;
        }

        private static decimal GetOutputStramount(NumberStyles styles, string amount)
        {
            var _amount = decimal.Parse(amount, styles).ToString("#,0.00;-#,0.00");
            return decimal.Parse(_amount);
        }

        public DataTable GetAAFData(DateTime dateparam)
        {
            #region dt Properties
            DataTable dtAaf = new DataTable();
            dtAaf.Columns.Add("AccountNo");
            dtAaf.Columns.Add("ClientName");
            dtAaf.Columns.Add("AO");
            dtAaf.Columns.Add("FacilityCode");
            dtAaf.Columns.Add("StatusPERSYSTEM");
            dtAaf.Columns.Add("ValueDate");
            dtAaf.Columns.Add("FirstDueDate");
            dtAaf.Columns.Add("MaturityDate");
            dtAaf.Columns.Add("SYSTEM");
            dtAaf.Columns.Add("AccountNo");
            dtAaf.Columns.Add("ClientName");
            dtAaf.Columns.Add("AO");
            dtAaf.Columns.Add("FacilityCode");
            dtAaf.Columns.Add("StatusPERSYSTEM");
            dtAaf.Columns.Add("ValueDate");
            dtAaf.Columns.Add("FirstDueDate");
            dtAaf.Columns.Add("MaturityDate");
            dtAaf.Columns.Add("TotalLoan");
            dtAaf.Columns.Add("OB");
            dtAaf.Columns.Add("MonthlyOB");
            dtAaf.Columns.Add("UDIBalance");
            dtAaf.Columns.Add("OrigERV");
            dtAaf.Columns.Add("PVRV");
            dtAaf.Columns.Add("OrigGD");
            dtAaf.Columns.Add("PVGD");
            dtAaf.Columns.Add("OriginalRate");
            dtAaf.Columns.Add("CurrentRate");
            dtAaf.Columns.Add("TermInmonths");
            dtAaf.Columns.Add("RemainingTermInMonths");
            dtAaf.Columns.Add("OriginalAmortizationAAF");
            dtAaf.Columns.Add("PaymentScheduleAmortizationAAF");
            dtAaf.Columns.Add("RepricedDate");
            dtAaf.Columns.Add("AAFICBSRateType");
            dtAaf.Columns.Add("RepricedAmortization");
            dtAaf.Columns.Add("PastDueDateITLDateExtractedPerAAFICBS");
            dtAaf.Columns.Add("PerFaMSAAFICBSIndustryCode");
            dtAaf.Columns.Add("IndustryHeader");
            dtAaf.Columns.Add("IndustryDetail");
            dtAaf.Columns.Add("Collateral");
            dtAaf.Columns.Add("PerFaMSAAFICBSAssetSizeInwords");
            dtAaf.Columns.Add("ICBSGLCODE");
            dtAaf.Columns.Add("ICBSGLName");
            dtAaf.Columns.Add("COSTCENTER");
            dtAaf.Columns.Add("BRANCHNAMEOFCOSTCENTERPERSYSTEM");
            dtAaf.Columns.Add("OriginatingBranchBooked");
            dtAaf.Columns.Add("NationalityPerICBS");
            dtAaf.Columns.Add("NextRateReviewDateExtractedPerFaMSAAFICBS");
            dtAaf.Columns.Add("TAXID");
            dtAaf.Columns.Add("CustomerTypeDescription");
            dtAaf.Columns.Add("RELCode");
            dtAaf.Columns.Add("REECode");
            dtAaf.Columns.Add("REEAddtlInfo");
            dtAaf.Columns.Add("AcctRef");
            dtAaf.Columns.Add("RPT");
            dtAaf.Columns.Add("ASSETCOST");
            dtAaf.Columns.Add("LeaseType");
            dtAaf.Columns.Add("ICBSCollateralCode");
            dtAaf.Columns.Add("AssetValue");
            dtAaf.Columns.Add("ApprovedAmount");
            dtAaf.Columns.Add("LastPrincipalPay");
            dtAaf.Columns.Add("PrincipalPayDate");
            dtAaf.Columns.Add("LastInterestPay");
            dtAaf.Columns.Add("LastInterestPayDate");
            dtAaf.Columns.Add("PreviousMonthsNPLTaggingByRisk");
            dtAaf.Columns.Add("SpecificRequiredProvisions");
            dtAaf.Columns.Add("GeneralRequiredProvisions");
            #endregion

            DataRow dr = null;

            #region Configuration
            string dbName = ConfigurationManager.AppSettings["AAFDBSource"];
            string dbServer = ConfigurationManager.AppSettings["AAFDBSource"];
            string dbDatabase = ConfigurationManager.AppSettings["AAFDBase"];
            string dbUserID = ConfigurationManager.AppSettings["AAFUserName"];
            string dbPassword = ConfigurationManager.AppSettings["AAFPassword"];
            string dbProviderName = ConfigurationManager.AppSettings["dbProviderName"];
            #endregion
            //string myconn = "Server=" + (dbServer) + ";Database=" + (dbDatabase) + ";User ID=" + Enc_Dec.Decrypt.Decryptor(dbUserID) + ";Password=" + Enc_Dec.Decrypt.Decryptor(dbPassword);
            string connstring = "Server=" + dbServer + ";Database=" + dbDatabase + ";User ID=" + dbUserID + ";Password=" + dbPassword;
            //Create the connection object
            using (SqlConnection conn = new SqlConnection(connstring))
            {
                // Open the SqlConnection.
                conn.Open();
                //Create the SQLCommand object
                using (SqlCommand command = new SqlCommand("dbo.BDOLFSP_AgingInventory", conn) { CommandType = CommandType.StoredProcedure })
                {
                    //Pass the parameter values here
                    command.Parameters.AddWithValue("@cutoffdate", dateparam);
                    command.CommandTimeout = 0;
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        //read the data
                        while (reader.Read())
                        {
                            dr = dtAaf.NewRow();

                            dr["AccountNo"] = reader[""].ToString();
                            dr["ClientName"] = reader[""].ToString();
                            dr["AO"] = reader[""].ToString();
                            dr["FacilityCode"] = reader[""].ToString();
                            dr["StatusPERSYSTEM"] = reader[""].ToString();
                            dr["ValueDate"] = reader[""].ToString();
                            dr["FirstDueDate"] = reader[""].ToString();
                            dr["MaturityDate"] = reader[""].ToString();
                            dr["SYSTEM"] = reader[""].ToString();
                            dr["AccountNo"] = reader[""].ToString();
                            dr["ClientName"] = reader[""].ToString();
                            dr["AO"] = reader[""].ToString();
                            dr["FacilityCode"] = reader[""].ToString();
                            dr["StatusPERSYSTEM"] = reader[""].ToString();
                            dr["ValueDate"] = reader[""].ToString();
                            dr["FirstDueDate"] = reader[""].ToString();
                            dr["MaturityDate"] = reader[""].ToString();
                            dr["TotalLoan"] = reader[""].ToString();
                            dr["OB"] = reader[""].ToString();
                            dr["MonthlyOB"] = reader[""].ToString();
                            dr["UDIBalance"] = reader[""].ToString();
                            dr["OrigERV"] = reader[""].ToString();
                            dr["PVRV"] = reader[""].ToString();
                            dr["OrigGD"] = reader[""].ToString();
                            dr["PVGD"] = reader[""].ToString();
                            dr["OriginalRate"] = reader[""].ToString();
                            dr["CurrentRate"] = reader[""].ToString();
                            dr["TermInmonths"] = reader[""].ToString();
                            dr["RemainingTermInMonths"] = reader[""].ToString();
                            dr["OriginalAmortizationAAF"] = reader[""].ToString();
                            dr["PaymentScheduleAmortizationAAF"] = reader[""].ToString();
                            dr["RepricedDate"] = reader[""].ToString();
                            dr["AAFICBSRateType"] = reader[""].ToString();
                            dr["RepricedAmortization"] = reader[""].ToString();
                            dr["PastDueDateITLDateExtractedPerAAFICBS"] = reader[""].ToString();
                            dr["PerFaMSAAFICBSIndustryCode"] = reader[""].ToString();
                            dr["IndustryHeader"] = reader[""].ToString();
                            dr["IndustryDetail"] = reader[""].ToString();
                            dr["Collateral"] = reader[""].ToString();
                            dr["PerFaMSAAFICBSAssetSizeInwords"] = reader[""].ToString();
                            dr["ICBSGLCODE"] = reader[""].ToString();
                            dr["ICBSGLName"] = reader[""].ToString();
                            dr["COSTCENTER"] = reader[""].ToString();
                            dr["BRANCHNAMEOFCOSTCENTERPERSYSTEM"] = reader[""].ToString();
                            dr["OriginatingBranchBooked"] = reader[""].ToString();
                            dr["NationalityPerICBS"] = reader[""].ToString();
                            dr["NextRateReviewDateExtractedPerFaMSAAFICBS"] = reader[""].ToString();
                            dr["TAXID"] = reader[""].ToString();
                            dr["CustomerTypeDescription"] = reader[""].ToString();
                            dr["RELCode"] = reader[""].ToString();
                            dr["REECode"] = reader[""].ToString();
                            dr["REEAddtlInfo"] = reader[""].ToString();
                            dr["AcctRef"] = reader[""].ToString();
                            dr["RPT"] = reader[""].ToString();
                            dr["ASSETCOST"] = reader[""].ToString();
                            dr["LeaseType"] = reader[""].ToString();
                            dr["ICBSCollateralCode"] = reader[""].ToString();
                            dr["AssetValue"] = reader[""].ToString();
                            dr["ApprovedAmount"] = reader[""].ToString();
                            dr["LastPrincipalPay"] = reader[""].ToString();
                            dr["PrincipalPayDate"] = reader[""].ToString();
                            dr["LastInterestPay"] = reader[""].ToString();
                            dr["LastInterestPayDate"] = reader[""].ToString();
                            dr["PreviousMonthsNPLTaggingByRisk"] = reader[""].ToString();
                            dr["SpecificRequiredProvisions"] = reader[""].ToString();
                            dr["GeneralRequiredProvisions"] = reader[""].ToString();

                        }
                    }
                }

                conn.Close();
            }

            return dtAaf;
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            txtSearch.Text = "";
            dgvConsolidator.DataSource = dtConso;
        }

        private void Search(string keyword)
        {
            if (!string.IsNullOrEmpty(keyword))
            {
                DataView dv = new DataView(dtConso);
                dv.RowFilter = "AccountNo LIKE '%" + keyword + "%' OR ClientName LIKE '%" + keyword + "%' OR ICBSGLCode LIKE '%" + keyword + "%' OR SYSTEM LIKE '%" + keyword + "%' OR UserName LIKE '%" + keyword + "%'";

                dgvConsolidator.DataSource = dv;
            }
            else
            {
                dgvConsolidator.DataSource = dtConso;
            }

        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            if (isInProcess) return;
            Search(txtSearch.Text);
        }

        private void txtSearch_Click(object sender, EventArgs e)
        {
            //  if (bgWorker.IsBusy) lblBusy.Text = "Busy processing, Please wait...";
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            //if (!bgWorker.IsBusy)
            //{
            //    lblBusy.Text = "No operation in progress to cancel";
            //    return;
            //}

            //DialogResult response = MetroMessageBox.Show(this, "\r\n\r\n Are you sure you want to cancel the process?", "Cancel", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            //if (response == DialogResult.Yes)
            //{
            //    this.bgWorker.CancelAsync();
            //    progressConso.Visible = false;
            //    lblPercent.Visible = false;
            //    lblBusy.Visible = false;
            //    MetroMessageBox.Show(this, "\r\n\r\nThe operation has been cancelled", "Cancel", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
            //}
        }

        private void btnExport_Click(object sender, EventArgs e)
        {

        }

        private DataTable GetAAFExcel()
        {
            string fullPathToExcel = _AafPath;
            string connString = string.Format("Provider=Microsoft.Jet.OLEDB.4.0;Data Source={0};Extended Properties='Excel 8.0;HDR=yes;IMEX=1;'", fullPathToExcel);

            DataTable dt = null;

            using (OleDbConnection conn = new OleDbConnection(connString))
            {
                conn.Open();
                OleDbCommand cmd = new OleDbCommand();
                DataTable dbSchema = conn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                if (dbSchema == null || dbSchema.Rows.Count < 1)
                {
                    throw new Exception("Error: Could not determined the name of the worksheet.");
                }

                string worksheetname = dbSchema.Rows[0]["TABLE_NAME"].ToString();

                OleDbDataAdapter da = new OleDbDataAdapter("SELECT * FROM [" + worksheetname + "]", conn);

                DataTable dtold = new DataTable(worksheetname);

                da.Fill(dtold);

                try
                {
                    dt = dtold.DefaultView.ToTable(false, "", "", "");
                }
                catch
                {
                    throw new Exception("Error: Unable to read columns in AAF file");
                }
            }
            return dt;
        }

        private DataTable AAFDataTable()
        {
            dtAaf = new DataTable("AAFDATA");

            dtAaf.Columns.Add("SYSTEM");
            dtAaf.Columns.Add("AccountNo");
            dtAaf.Columns.Add("ClientName");
            dtAaf.Columns.Add("AO");
            dtAaf.Columns.Add("FacilityCode");
            dtAaf.Columns.Add("StatusPERSYSTEM");
            dtAaf.Columns.Add("ValueDate");
            dtAaf.Columns.Add("FirstDueDate");
            dtAaf.Columns.Add("MaturityDate");
            dtAaf.Columns.Add("TotalLoan");
            dtAaf.Columns.Add("OB");
            dtAaf.Columns.Add("MonthlyOB");
            dtAaf.Columns.Add("UDIBalance");
            dtAaf.Columns.Add("OrigERV");
            dtAaf.Columns.Add("PVRV");
            dtAaf.Columns.Add("OrigGD");
            dtAaf.Columns.Add("PVGD");
            dtAaf.Columns.Add("OriginalRate");
            dtAaf.Columns.Add("CurrentRate");
            dtAaf.Columns.Add("TermInmonths");
            dtAaf.Columns.Add("RemainingTermInMonths");
            dtAaf.Columns.Add("OriginalAmortizationAAF");
            dtAaf.Columns.Add("PaymentScheduleAmortizationAAF");
            dtAaf.Columns.Add("RepricedDate");
            dtAaf.Columns.Add("AAFICBSRateType");
            dtAaf.Columns.Add("RepricedAmortization");
            dtAaf.Columns.Add("PastDueDateITLDateExtractedPerAAFICBS");
            dtAaf.Columns.Add("PerFaMSAAFICBSIndustryCode");
            dtAaf.Columns.Add("IndustryHeader");
            dtAaf.Columns.Add("IndustryDetail");
            dtAaf.Columns.Add("Collateral");
            dtAaf.Columns.Add("PerFaMSAAFICBSAssetSizeInwords");
            dtAaf.Columns.Add("ICBSGLCODE");
            dtAaf.Columns.Add("ICBSGLName");
            dtAaf.Columns.Add("COSTCENTER");
            dtAaf.Columns.Add("BRANCHNAMEOFCOSTCENTERPERSYSTEM");
            dtAaf.Columns.Add("OriginatingBranchBooked");
            dtAaf.Columns.Add("NationalityPerICBS");
            dtAaf.Columns.Add("NextRateReviewDateExtractedPerFaMSAAFICBS");
            dtAaf.Columns.Add("TAXID");
            dtAaf.Columns.Add("CustomerTypeDescription");
            dtAaf.Columns.Add("RELCode");
            dtAaf.Columns.Add("REECode");
            dtAaf.Columns.Add("REEAddtlInfo");
            dtAaf.Columns.Add("AcctRef");
            dtAaf.Columns.Add("RPT");
            dtAaf.Columns.Add("ASSETCOST");
            dtAaf.Columns.Add("LeaseType");
            dtAaf.Columns.Add("ICBSCollateralCode");
            dtAaf.Columns.Add("AssetValue");
            dtAaf.Columns.Add("ApprovedAmount");
            dtAaf.Columns.Add("CPNumber");
            dtAaf.Columns.Add("LastPrincipalPay");
            dtAaf.Columns.Add("PrincipalPayDate");
            dtAaf.Columns.Add("LastInterestPay");
            dtAaf.Columns.Add("LastInterestPayDate");
            dtAaf.Columns.Add("PreviousMonthsNPLTaggingByRisk");
            dtAaf.Columns.Add("SpecificRequiredProvisions");
            dtAaf.Columns.Add("GeneralRequiredProvisions");

            return dtAaf;
        }

        private void toolStripLabel1_Click(object sender, EventArgs e)
        {

        }

        private void toolStripButton4_Click(object sender, EventArgs e)
        {

        }

        private void setRawFilePathToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmPathMaintenance frmMaintenance = frmPathMaintenance.Instance();
            // frmMaintenance.TopMost = true;
            frmMaintenance.ShowDialog();
        }

        private void uSDollarExchangeRateToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmExchangeRate frmExchange = frmExchangeRate.Instance();
            frmExchange.ShowDialog();
        }

        private void exportToExcelToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void gLCodeAndDescriptionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmCorrespondingGL frmcorrespondingGL = frmCorrespondingGL.Instance();
            frmcorrespondingGL.ShowDialog();
        }

        private void qualifyingTableToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmQualifyingCapital frmqualifyingCapital = frmQualifyingCapital.Instance();
            frmqualifyingCapital.ShowDialog();
        }

        private void accountUnderLitigationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmUnderLitigation frmunderLitigation = frmUnderLitigation.Instance();
            frmunderLitigation.ShowDialog();
        }

        private void nTCConsolidatorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            NTCColumnNames();




            dtExport = consolidatorRepository.GetAll().ToDataTable();

            dtExport.Columns.Remove("TransID");
            dtExport.Columns.Remove("RawFiles");
            dtExport.Columns.Remove("isConsolidated");
            dtExport.Columns.Remove("isDeleted");
            dtExport.Columns.Remove("UserName");
            dtExport.Columns.Remove("TransDate");
            dtExport.Columns.Remove("Reason");
            dtExport.Columns.Remove("RecordDate");

            SaveFileDialog diag = new SaveFileDialog();
            diag.Filter = "Excel Files(.xls)|*.xls";//| Excel Files(.xlsx) | *.xlsx";
            //diag.Filter = "All files (*.*)|*.*";
            diag.FilterIndex = 0;
            diag.RestoreDirectory = true;
            //  diag.CreatePrompt = true;
            diag.Title = "Export NTC Consolidator To Excel File";

            if (dtExport.Rows.Count > 0)
            {
                if (diag.ShowDialog() == DialogResult.OK)
                {
                    ExportFilename = diag.FileName;


                    //  ExportWorker
                    pnlWaitInfo.Visible = true;
                    ExportWorker = new BackgroundWorker();
                    ExportWorker.WorkerReportsProgress = true;
                    ExportWorker.DoWork += new DoWorkEventHandler(ExportWorker_DoWork);
                    ExportWorker.RunWorkerCompleted += new RunWorkerCompletedEventHandler(ExportWorker_RunWorkerCompleted);
                    ExportWorker.ProgressChanged += new ProgressChangedEventHandler(ExportWorker_ProgressChanged);
                    ExportWorker.RunWorkerAsync();
                }
            }
        }

        #region Export BGWorker
        private void ExportWorker_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            pnlWaitInfo.Visible = true;
            lblWaitInfo.Text = "Fetching record, Please wait..."; //header text
            lblWaitStatus.Text = "Status: Exporting is in progress...";
        }

        private void ExportWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (e.Error != null)
            {
                pnlWaitInfo.Visible = false;
                lblWaitInfo.Text = "Error";
                lblWaitStatus.Text = "Status: Error Encountered while exporting";
                MetroMessageBox.Show(this, "\r\nOop! Something went wrong and couldn't process your request.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else
            {
                pnlWaitInfo.Visible = false;
                MetroMessageBox.Show(this, "\r\n" + Path.GetFileName(ExportFilename) + " was successfully generated.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void ExportWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            try
            {
                frmReportViewer rpt = new frmReportViewer();
                rpt.ShowDialog();
               // rpt.ExportToExcel("dsNTCReport", "NTC Consolidated File", dtExport, ExportFilename, "Excel", "NTCConsolidatorReport.rdlc", "NTCColumnNames Consolidated Report");

                #region Hide Temp
                /*
                        StreamWriter wr = new StreamWriter(ExportFilename);

                        //Create Title of the report
                        wr.Write("NTC Consolidated Report \r\n");
                        wr.Write("For the Month of: " + DateTime.Today.ToString("MMMM") + ", " + Convert.ToString(DateTime.Today.Year));
                        wr.WriteLine();
                        wr.WriteLine();
                        wr.Write("Printed Date Time: " + DateTime.Now.ToString("MM/dd/yyyy h:mm tt"));
                        wr.WriteLine();
                        wr.WriteLine();
                        for (int i = 0; i < dtExport.Columns.Count; i++)
                        {
                            wr.Write(dtExport.Columns[i].ToString().ToUpper() + "\t");
                        }

                        wr.WriteLine();

                        //write rows to excel file
                        for (int i = 0; i < (dtExport.Rows.Count); i++)
                        {
                            for (int j = 0; j < dtExport.Columns.Count; j++)
                            {
                                if (dtExport.Rows[i][j] != null)
                                {
                                    wr.Write("" + Convert.ToString(dtExport.Rows[i][j]) + "" + "\t");
                                }
                                else
                                {
                                    wr.Write("\t");
                                }
                            }
                            //go to next line
                            wr.WriteLine();
                            ExportWorker.ReportProgress(0);
                        }

                        //close file
                        wr.Close();

                        */
                #endregion
            }
            catch (Exception ex)
            {
                throw;
            }


        }
        #endregion

        private void exportToExcelToolStripMenuItem_Click_1(object sender, EventArgs e)
        {

        }

        private DataTable NTCColumnNames()
        {
            dtExport = new DataTable("dtExport");
            dtExport.Columns.Add("TransID", typeof(int));
            dtExport.Columns.Add("RawFiles", typeof(String));
            dtExport.Columns.Add("isConsolidated", typeof(bool));
            dtExport.Columns.Add("isDeleted", typeof(bool));
            dtExport.Columns.Add("UserName", typeof(String));
            dtExport.Columns.Add("TransDate", typeof(DateTime));
            dtExport.Columns.Add("RecordDate", typeof(DateTime));
            dtExport.Columns.Add("SYSTEM", typeof(String));
            dtExport.Columns.Add("AccountNo", typeof(String));
            dtExport.Columns.Add("ClientName", typeof(String));
            dtExport.Columns.Add("AO", typeof(String));
            dtExport.Columns.Add("FacilityCode", typeof(String));
            dtExport.Columns.Add("StatusPerSystem", typeof(String));
            dtExport.Columns.Add("ValueDate", typeof(DateTime));
            dtExport.Columns.Add("FirstDueDate", typeof(DateTime));
            dtExport.Columns.Add("MaturityDate", typeof(DateTime));
            dtExport.Columns.Add("TotalLoan", typeof(decimal));
            dtExport.Columns.Add("OB", typeof(decimal));
            dtExport.Columns.Add("MonthlyOB", typeof(decimal));
            dtExport.Columns.Add("UDIBalance", typeof(decimal));
            dtExport.Columns.Add("ClientsEquity", typeof(decimal));
            dtExport.Columns.Add("AccruedInterestReceivable", typeof(decimal));
            dtExport.Columns.Add("OrigERV", typeof(decimal));
            dtExport.Columns.Add("PVRV", typeof(decimal));
            dtExport.Columns.Add("OrigGD", typeof(decimal));
            dtExport.Columns.Add("PVGD", typeof(decimal));
            dtExport.Columns.Add("TotalLoanPortfolio", typeof(decimal));
            dtExport.Columns.Add("NTC", typeof(String));
            dtExport.Columns.Add("OriginalRate", typeof(decimal));
            dtExport.Columns.Add("CurrentRate", typeof(decimal));
            dtExport.Columns.Add("TermInMonths", typeof(int));
            dtExport.Columns.Add("RemainingTermInMonths", typeof(int));
            dtExport.Columns.Add("OriginalAmortizationAAF", typeof(decimal));
            dtExport.Columns.Add("PaymentScheduleAmortizationAAF", typeof(decimal));
            dtExport.Columns.Add("RepricedDate", typeof(DateTime));
            dtExport.Columns.Add("AAFICBSRateType", typeof(String));
            dtExport.Columns.Add("RepricedAmortization", typeof(decimal));
            dtExport.Columns.Add("PastDueDateITLDateExtractedPerAAFICBS", typeof(String));
            dtExport.Columns.Add("PerFaMSAAFICBSIndustryCode", typeof(String));
            dtExport.Columns.Add("IndustryHeader", typeof(String));
            dtExport.Columns.Add("IndustryDetail", typeof(String));
            dtExport.Columns.Add("Collateral", typeof(String));
            dtExport.Columns.Add("PerFaMSAAFICBSAssetSize", typeof(String));
            dtExport.Columns.Add("PerFaMSAAFICBSAssetSizeInWords", typeof(String));
            dtExport.Columns.Add("ICBSGLCode", typeof(String));
            dtExport.Columns.Add("ICBSGLName", typeof(String));
            dtExport.Columns.Add("CostCenter", typeof(String));
            dtExport.Columns.Add("BranchNameOfCostCenterPerSystem", typeof(String));
            dtExport.Columns.Add("StatusPerGL", typeof(String));
            dtExport.Columns.Add("OriginatingBranchBooked", typeof(String));
            dtExport.Columns.Add("NationalityPerICBS", typeof(String));
            dtExport.Columns.Add("NextRateReviewDateExtractedPerFaMSAAFICBS", typeof(DateTime));
            dtExport.Columns.Add("TaxID", typeof(String));
            dtExport.Columns.Add("LoanPurposeCode", typeof(String));
            dtExport.Columns.Add("MaturityTypeCode", typeof(String));
            dtExport.Columns.Add("BankRelationship", typeof(String));
            dtExport.Columns.Add("SyndicatedLoanInd", typeof(String));
            dtExport.Columns.Add("CustomerTypeDescription", typeof(String));
            dtExport.Columns.Add("RELCode", typeof(String));
            dtExport.Columns.Add("REECode", typeof(String));
            dtExport.Columns.Add("REEAddtlInfo", typeof(String));
            dtExport.Columns.Add("AcctRef", typeof(String));
            dtExport.Columns.Add("RPT", typeof(String));
            dtExport.Columns.Add("ASSETCOST", typeof(decimal));
            dtExport.Columns.Add("LeaseType", typeof(String));
            dtExport.Columns.Add("Provisioning", typeof(String));
            dtExport.Columns.Add("Matrix", typeof(String));
            dtExport.Columns.Add("Remarks", typeof(String));
            dtExport.Columns.Add("ICBSCollateralCode", typeof(String));
            dtExport.Columns.Add("AssetValue", typeof(decimal));
            dtExport.Columns.Add("ApprovedAmount", typeof(decimal));
            dtExport.Columns.Add("CPNumber", typeof(String));
            dtExport.Columns.Add("LastPrincipalPay", typeof(Int64));
            dtExport.Columns.Add("PrincipalPayDate", typeof(DateTime));
            dtExport.Columns.Add("LastInterestPay", typeof(decimal));
            dtExport.Columns.Add("LastInterestPayDate", typeof(DateTime));
            dtExport.Columns.Add("PreviousMonthsNPLTaggingByRisk", typeof(String));
            dtExport.Columns.Add("SpecificRequiredProvisions", typeof(String));
            dtExport.Columns.Add("GeneralRequiredProvisions", typeof(String));
            dtExport.Columns.Add("Reason", typeof(String));

            return dtExport;

        }

        private void aAFMigratedToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmMigratedAccount frmmigratedAccount = frmMigratedAccount.Instance();
            frmmigratedAccount.ShowDialog();
        }

        private void faMSPastDueAccountToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmPastDue frmpastDue = frmPastDue.Instance();
            frmpastDue.ShowDialog();
        }

        private void dailyGLToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmDailyGL frmdailyGL = frmDailyGL.Instance();
            frmdailyGL.ShowDialog();
        }

        private void LoadGLData()
        {
            dtGLCODE = new DataTable();
            dtGLCODE = correspondingGLRepository.GetGL().ToDataTable();
        }

        private void nTCReportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmReportViewer rpt = new frmReportViewer();
            rpt.ShowDialog();
        }

        private void aPLFromRiskToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmAPLAccount apl = new frmAPLAccount();
            apl.ShowDialog();
        }
    }


    #region "Override MenuStrip Border"
    public class CustomColorTable : ProfessionalColorTable
    {
        public override Color MenuItemBorder
        {
            get { return Color.White; }
        }
    }
    #endregion
}

