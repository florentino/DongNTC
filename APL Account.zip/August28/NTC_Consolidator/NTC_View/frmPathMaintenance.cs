﻿using MetroFramework;
using NTC_Consolidator.Core.Interfaces;
using NTC_Consolidator.Core.Repository;
using NTC_Consolidator.Data;
using NTC_Consolidator.NTC_Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Data.Entity;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NTC_Consolidator.NTC_View
{
    public partial class frmPathMaintenance : MetroFramework.Forms.MetroForm
    {
        private string _icbs = "";
        private string _icbsEXT = "";
        private string _aafEXT = "";
        private string _aaf = "";
        private string _fams = "";
        private string _famsEXT = "";

        private IFilePathRepository filePathRepository;

        private static frmPathMaintenance mform = null;

        public static frmPathMaintenance Instance()
        {
            if (mform == null)
            {
                mform = new frmPathMaintenance();
            }
            return mform;
        }

        public frmPathMaintenance()
        {
            InitializeComponent();
            this.filePathRepository = new FilePathRepository(new NTC_Context_Entities());
        }

        private void frmPathMaintenance_Load(object sender, EventArgs e)
        {

        }

        private void btnICBSBrowse_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Title = "NTC Consolidator";
            dlg.Filter = "Text Files(.txt) | *.txt| CSV Files(.csv)|*.csv";


            // dlg.Multiselect = true;

            DialogResult dr = dlg.ShowDialog();

            if (dr == DialogResult.OK)
            {
                //var getFullPath = Path.GetFullPath(dlg.FileName);
                _icbs = Path.GetDirectoryName(dlg.FileName);
                _icbsEXT = Path.GetExtension(dlg.FileName);
                txtICBSFilePath.Text = dlg.FileName;
            }
        }

        private void btnAAFBrowse_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Title = "NTC Consolidator";
            dlg.Filter = "Excel Files(.xls)|*.xls";//| Excel Files(.xlsx) | *.xlsx";
            // dlg.Multiselect = true;

            DialogResult dr = dlg.ShowDialog();

            if (dr == DialogResult.OK)
            {
                _aaf = Path.GetDirectoryName(dlg.FileName);
                _aafEXT = Path.GetExtension(dlg.FileName);
                txtAAFFilePath.Text = dlg.FileName;
            }
        }

        private void btnFAMSBrowse_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Title = "NTC Consolidator";
            dlg.Filter = "Excel Files(.xls)|*.xls";//| Excel Files(.xlsx) | *.xlsx";
            // dlg.Multiselect = true;

            DialogResult dr = dlg.ShowDialog();

            if (dr == DialogResult.OK)
            {
                _fams = Path.GetDirectoryName(dlg.FileName);//dlg.FileName;
                _famsEXT = Path.GetExtension(dlg.FileName);
                txtFAMSFilePath.Text = dlg.FileName;
            }
        }


        private bool IsValid(bool isPassed, FilePathMaintenance maintenance, string icbs, string aaf, string fams)
        {
            isPassed = true;

            try
            {
                if (string.IsNullOrEmpty(icbs))
                {
                    maintenance.ICBSFilePath = "";
                }
                else
                {
                    lblErrIcbs.Text = "";
                }
            }
            catch (ValidationException ex)
            {
                lblErrIcbs.Text = ex.Message;
                isPassed = false;
            }

            try
            {
                if (string.IsNullOrEmpty(aaf))
                {
                    maintenance.AAFFilePath = "";
                }
                else
                {
                    lblErrAAF.Text = "";
                }
            }
            catch (ValidationException ex)
            {
                lblErrAAF.Text = ex.Message;
                isPassed = false;
            }

            try
            {
                if (string.IsNullOrEmpty(fams))
                {
                    maintenance.FAMSFilePath = "";
                }
                else
                {
                    lblErrFAMS.Text = "";
                }
            }
            catch (ValidationException ex)
            {
                lblErrFAMS.Text = ex.Message;
                isPassed = false;
            }

            if(isPassed)
            {
                
            }

            return isPassed;
        }


        private void btnOK_Click(object sender, EventArgs e)
        {
            FilePathMaintenance maintenance = new FilePathMaintenance();

            
            var isPassed = false;
            isPassed = IsValid(isPassed, maintenance, txtICBSFilePath.Text, txtAAFFilePath.Text, txtFAMSFilePath.Text); //Check for Valid Input

           if (!isPassed) return;

            //if (txtICBSFilePath.Text == "" || txtFAMSFilePath.Text == "" || txtAAFFilePath.Text == "")
            //{
            //    MetroMessageBox.Show(this, "\r\n\r\nPath is not specified.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            //    return;
            //}

            try
            {
                var filePathMaintenance = new BDOLF_PathMaintenance();
                filePathMaintenance.ICBSFilePath = _icbs;
                filePathMaintenance.ICBSFileExtension = _icbsEXT;
                filePathMaintenance.ICBSTextKeyword = "";
                filePathMaintenance.AAFFilePath = _aaf;
                filePathMaintenance.AAFFileExtension = _aafEXT;
                filePathMaintenance.AAFTextKeyword = "";
                filePathMaintenance.FAMSFilePath = _fams;
                filePathMaintenance.FAMSFileExtension = _famsEXT;
                filePathMaintenance.FAMSTextKeyword = "";
                filePathMaintenance.UserName = frmConsolidator.UserName;
                filePathMaintenance.DateInserted = DateTime.Now;

                filePathRepository.TruncateTable();

                filePathRepository.InsertFilePathMaintenace(filePathMaintenance);

                filePathRepository.Save();

                MetroMessageBox.Show(this, "\r\n\r\nSuccessfully saved", "Raw File Path Maintenance", MessageBoxButtons.OK, MessageBoxIcon.Information);

                this.Close();
            }
            catch (Exception ex)
            {
                MetroMessageBox.Show(this, "\r\n\r\nError encountered, Please contact your system administrator", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }

        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            frmPathMaintenance.mform = null;
            this.Close();
        }

        private void frmPathMaintenance_FormClosed(object sender, FormClosedEventArgs e)
        {
            frmPathMaintenance.mform = null;
        }
    }
}
