﻿namespace NTC_Consolidator.NTC_View
{
    partial class frmReportViewer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource1 = new Microsoft.Reporting.WinForms.ReportDataSource();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmReportViewer));
            this.reportViewer1 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.btnExecute = new MetroFramework.Controls.MetroButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.cmbDateTo = new MetroFramework.Controls.MetroDateTime();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.cmbDateFrom = new MetroFramework.Controls.MetroDateTime();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.pnlWaitInfo = new System.Windows.Forms.Panel();
            this.lblWaitStatus1 = new MetroFramework.Controls.MetroLabel();
            this.lblWaitFilePath = new MetroFramework.Controls.MetroLabel();
            this.lblWaitStatus = new MetroFramework.Controls.MetroLabel();
            this.lblWaitInfo = new MetroFramework.Controls.MetroLabel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.ConsoMenu = new System.Windows.Forms.ToolStrip();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripDropDownButton();
            this.nTCReportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.consolidatorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.correspondingGLToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dailyGLToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exchangeRateToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.migratedAccountToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pastDueToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.qualifyingCapitalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.underLitigationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.summaryReportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exceptionalReportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aAFBlankIndustryCodeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aAFDOSRITAGGINGToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aAFZeroAssetSizeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.iCBSBlankIndustryCodeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.iCBSDOSRITaggingToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.iCBSZeroAssetSizeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.differenceInTaggingOfRiskAndGLToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.txtRptName = new MetroFramework.Controls.MetroTextBox();
            this.btnExport = new MetroFramework.Controls.MetroButton();
            this.panel1.SuspendLayout();
            this.pnlWaitInfo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel2.SuspendLayout();
            this.ConsoMenu.SuspendLayout();
            this.SuspendLayout();
            // 
            // reportViewer1
            // 
            reportDataSource1.Name = "DataSet1";
            reportDataSource1.Value = null;
            this.reportViewer1.LocalReport.DataSources.Add(reportDataSource1);
            this.reportViewer1.LocalReport.ReportEmbeddedResource = "";
            this.reportViewer1.Location = new System.Drawing.Point(37, 170);
            this.reportViewer1.Margin = new System.Windows.Forms.Padding(4);
            this.reportViewer1.Name = "reportViewer1";
            this.reportViewer1.ShowToolBar = false;
            this.reportViewer1.Size = new System.Drawing.Size(1533, 563);
            this.reportViewer1.TabIndex = 0;
            // 
            // btnExecute
            // 
            this.btnExecute.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnExecute.Location = new System.Drawing.Point(1471, 126);
            this.btnExecute.Margin = new System.Windows.Forms.Padding(4);
            this.btnExecute.Name = "btnExecute";
            this.btnExecute.Size = new System.Drawing.Size(99, 36);
            this.btnExecute.TabIndex = 87;
            this.btnExecute.Text = "&Load Data";
            this.btnExecute.UseCustomBackColor = true;
            this.btnExecute.UseCustomForeColor = true;
            this.btnExecute.UseSelectable = true;
            this.btnExecute.UseStyleColors = true;
            this.btnExecute.Click += new System.EventHandler(this.btnExecute_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.cmbDateTo);
            this.panel1.Controls.Add(this.metroLabel3);
            this.panel1.Controls.Add(this.cmbDateFrom);
            this.panel1.Controls.Add(this.metroLabel1);
            this.panel1.Location = new System.Drawing.Point(683, 117);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(596, 52);
            this.panel1.TabIndex = 88;
            // 
            // cmbDateTo
            // 
            this.cmbDateTo.CustomFormat = "MM/dd/yyyy";
            this.cmbDateTo.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.cmbDateTo.Location = new System.Drawing.Point(397, 9);
            this.cmbDateTo.Margin = new System.Windows.Forms.Padding(4);
            this.cmbDateTo.MinDate = new System.DateTime(2018, 6, 1, 0, 0, 0, 0);
            this.cmbDateTo.MinimumSize = new System.Drawing.Size(0, 30);
            this.cmbDateTo.Name = "cmbDateTo";
            this.cmbDateTo.Size = new System.Drawing.Size(191, 30);
            this.cmbDateTo.TabIndex = 91;
            // 
            // metroLabel3
            // 
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.Location = new System.Drawing.Point(315, 21);
            this.metroLabel3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(63, 20);
            this.metroLabel3.TabIndex = 90;
            this.metroLabel3.Text = "Date To: ";
            // 
            // cmbDateFrom
            // 
            this.cmbDateFrom.CustomFormat = "MM/dd/yyyy";
            this.cmbDateFrom.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.cmbDateFrom.Location = new System.Drawing.Point(105, 9);
            this.cmbDateFrom.Margin = new System.Windows.Forms.Padding(4);
            this.cmbDateFrom.MinDate = new System.DateTime(2018, 6, 1, 0, 0, 0, 0);
            this.cmbDateFrom.MinimumSize = new System.Drawing.Size(0, 30);
            this.cmbDateFrom.Name = "cmbDateFrom";
            this.cmbDateFrom.Size = new System.Drawing.Size(191, 30);
            this.cmbDateFrom.TabIndex = 89;
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.Location = new System.Drawing.Point(3, 21);
            this.metroLabel1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(81, 20);
            this.metroLabel1.TabIndex = 34;
            this.metroLabel1.Text = "Date From: ";
            // 
            // pnlWaitInfo
            // 
            this.pnlWaitInfo.BackColor = System.Drawing.Color.Transparent;
            this.pnlWaitInfo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlWaitInfo.Controls.Add(this.lblWaitStatus1);
            this.pnlWaitInfo.Controls.Add(this.lblWaitFilePath);
            this.pnlWaitInfo.Controls.Add(this.lblWaitStatus);
            this.pnlWaitInfo.Controls.Add(this.lblWaitInfo);
            this.pnlWaitInfo.Controls.Add(this.pictureBox1);
            this.pnlWaitInfo.Location = new System.Drawing.Point(479, 889);
            this.pnlWaitInfo.Margin = new System.Windows.Forms.Padding(4);
            this.pnlWaitInfo.Name = "pnlWaitInfo";
            this.pnlWaitInfo.Size = new System.Drawing.Size(434, 144);
            this.pnlWaitInfo.TabIndex = 89;
            // 
            // lblWaitStatus1
            // 
            this.lblWaitStatus1.FontSize = MetroFramework.MetroLabelSize.Small;
            this.lblWaitStatus1.Location = new System.Drawing.Point(4, 192);
            this.lblWaitStatus1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblWaitStatus1.Name = "lblWaitStatus1";
            this.lblWaitStatus1.Size = new System.Drawing.Size(429, 23);
            this.lblWaitStatus1.TabIndex = 4;
            this.lblWaitStatus1.Text = "Total Numbers of Records:";
            this.lblWaitStatus1.Visible = false;
            // 
            // lblWaitFilePath
            // 
            this.lblWaitFilePath.FontSize = MetroFramework.MetroLabelSize.Small;
            this.lblWaitFilePath.Location = new System.Drawing.Point(4, 215);
            this.lblWaitFilePath.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblWaitFilePath.Name = "lblWaitFilePath";
            this.lblWaitFilePath.Size = new System.Drawing.Size(429, 23);
            this.lblWaitFilePath.TabIndex = 3;
            this.lblWaitFilePath.Text = "File Path:";
            this.lblWaitFilePath.Visible = false;
            // 
            // lblWaitStatus
            // 
            this.lblWaitStatus.FontSize = MetroFramework.MetroLabelSize.Small;
            this.lblWaitStatus.Location = new System.Drawing.Point(4, 112);
            this.lblWaitStatus.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblWaitStatus.Name = "lblWaitStatus";
            this.lblWaitStatus.Size = new System.Drawing.Size(429, 23);
            this.lblWaitStatus.TabIndex = 2;
            this.lblWaitStatus.Text = "Status: ";
            // 
            // lblWaitInfo
            // 
            this.lblWaitInfo.FontSize = MetroFramework.MetroLabelSize.Small;
            this.lblWaitInfo.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.lblWaitInfo.Location = new System.Drawing.Point(4, 74);
            this.lblWaitInfo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblWaitInfo.Name = "lblWaitInfo";
            this.lblWaitInfo.Size = new System.Drawing.Size(424, 28);
            this.lblWaitInfo.TabIndex = 1;
            this.lblWaitInfo.Text = "Reading ICBS Raw File, Please Wait...";
            this.lblWaitInfo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::NTC_Consolidator.Properties.Resources.lg_discuss_ellipsis_preloader;
            this.pictureBox1.Location = new System.Drawing.Point(4, -17);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(424, 116);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // panel3
            // 
            this.panel3.Location = new System.Drawing.Point(37, 159);
            this.panel3.Margin = new System.Windows.Forms.Padding(4);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(71, 12);
            this.panel3.TabIndex = 95;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.panel4);
            this.panel2.Controls.Add(this.ConsoMenu);
            this.panel2.Location = new System.Drawing.Point(37, 126);
            this.panel2.Margin = new System.Windows.Forms.Padding(4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(67, 34);
            this.panel2.TabIndex = 94;
            // 
            // panel4
            // 
            this.panel4.Location = new System.Drawing.Point(57, 0);
            this.panel4.Margin = new System.Windows.Forms.Padding(4);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(13, 33);
            this.panel4.TabIndex = 51;
            // 
            // ConsoMenu
            // 
            this.ConsoMenu.BackColor = System.Drawing.Color.Transparent;
            this.ConsoMenu.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ConsoMenu.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.ConsoMenu.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.ConsoMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton1});
            this.ConsoMenu.Location = new System.Drawing.Point(0, 0);
            this.ConsoMenu.Name = "ConsoMenu";
            this.ConsoMenu.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional;
            this.ConsoMenu.Size = new System.Drawing.Size(67, 34);
            this.ConsoMenu.TabIndex = 1;
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.nTCReportToolStripMenuItem,
            this.exceptionalReportToolStripMenuItem});
            this.toolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton1.Image")));
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(34, 31);
            this.toolStripButton1.Text = "ttReports";
            this.toolStripButton1.ToolTipText = "Exceptional Reports";
            // 
            // nTCReportToolStripMenuItem
            // 
            this.nTCReportToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.consolidatorToolStripMenuItem,
            this.correspondingGLToolStripMenuItem,
            this.dailyGLToolStripMenuItem,
            this.exchangeRateToolStripMenuItem,
            this.migratedAccountToolStripMenuItem,
            this.pastDueToolStripMenuItem,
            this.qualifyingCapitalToolStripMenuItem,
            this.underLitigationToolStripMenuItem,
            this.summaryReportToolStripMenuItem});
            this.nTCReportToolStripMenuItem.Name = "nTCReportToolStripMenuItem";
            this.nTCReportToolStripMenuItem.Size = new System.Drawing.Size(210, 26);
            this.nTCReportToolStripMenuItem.Text = "NTC Report";
            // 
            // consolidatorToolStripMenuItem
            // 
            this.consolidatorToolStripMenuItem.Name = "consolidatorToolStripMenuItem";
            this.consolidatorToolStripMenuItem.Size = new System.Drawing.Size(203, 26);
            this.consolidatorToolStripMenuItem.Text = "Consolidator";
            this.consolidatorToolStripMenuItem.Click += new System.EventHandler(this.consolidatorToolStripMenuItem_Click);
            this.consolidatorToolStripMenuItem.MouseHover += new System.EventHandler(this.consolidatorToolStripMenuItem_MouseHover);
            // 
            // correspondingGLToolStripMenuItem
            // 
            this.correspondingGLToolStripMenuItem.Name = "correspondingGLToolStripMenuItem";
            this.correspondingGLToolStripMenuItem.Size = new System.Drawing.Size(203, 26);
            this.correspondingGLToolStripMenuItem.Text = "Corresponding GL";
            this.correspondingGLToolStripMenuItem.Visible = false;
            this.correspondingGLToolStripMenuItem.Click += new System.EventHandler(this.correspondingGLToolStripMenuItem_Click);
            this.correspondingGLToolStripMenuItem.MouseHover += new System.EventHandler(this.correspondingGLToolStripMenuItem_MouseHover);
            // 
            // dailyGLToolStripMenuItem
            // 
            this.dailyGLToolStripMenuItem.Name = "dailyGLToolStripMenuItem";
            this.dailyGLToolStripMenuItem.Size = new System.Drawing.Size(203, 26);
            this.dailyGLToolStripMenuItem.Text = "Daily GL";
            this.dailyGLToolStripMenuItem.Visible = false;
            this.dailyGLToolStripMenuItem.Click += new System.EventHandler(this.dailyGLToolStripMenuItem_Click);
            this.dailyGLToolStripMenuItem.MouseHover += new System.EventHandler(this.dailyGLToolStripMenuItem_MouseHover);
            // 
            // exchangeRateToolStripMenuItem
            // 
            this.exchangeRateToolStripMenuItem.Name = "exchangeRateToolStripMenuItem";
            this.exchangeRateToolStripMenuItem.Size = new System.Drawing.Size(203, 26);
            this.exchangeRateToolStripMenuItem.Text = "Exchange Rate";
            this.exchangeRateToolStripMenuItem.Visible = false;
            this.exchangeRateToolStripMenuItem.Click += new System.EventHandler(this.exchangeRateToolStripMenuItem_Click);
            this.exchangeRateToolStripMenuItem.MouseHover += new System.EventHandler(this.exchangeRateToolStripMenuItem_MouseHover);
            // 
            // migratedAccountToolStripMenuItem
            // 
            this.migratedAccountToolStripMenuItem.Name = "migratedAccountToolStripMenuItem";
            this.migratedAccountToolStripMenuItem.Size = new System.Drawing.Size(203, 26);
            this.migratedAccountToolStripMenuItem.Text = "Migrated Account";
            this.migratedAccountToolStripMenuItem.Visible = false;
            this.migratedAccountToolStripMenuItem.Click += new System.EventHandler(this.migratedAccountToolStripMenuItem_Click);
            this.migratedAccountToolStripMenuItem.MouseHover += new System.EventHandler(this.migratedAccountToolStripMenuItem_MouseHover);
            // 
            // pastDueToolStripMenuItem
            // 
            this.pastDueToolStripMenuItem.Name = "pastDueToolStripMenuItem";
            this.pastDueToolStripMenuItem.Size = new System.Drawing.Size(203, 26);
            this.pastDueToolStripMenuItem.Text = "Past Due";
            this.pastDueToolStripMenuItem.Visible = false;
            this.pastDueToolStripMenuItem.Click += new System.EventHandler(this.pastDueToolStripMenuItem_Click);
            this.pastDueToolStripMenuItem.MouseHover += new System.EventHandler(this.pastDueToolStripMenuItem_MouseHover);
            // 
            // qualifyingCapitalToolStripMenuItem
            // 
            this.qualifyingCapitalToolStripMenuItem.Name = "qualifyingCapitalToolStripMenuItem";
            this.qualifyingCapitalToolStripMenuItem.Size = new System.Drawing.Size(203, 26);
            this.qualifyingCapitalToolStripMenuItem.Text = "Qualifying Capital";
            this.qualifyingCapitalToolStripMenuItem.Visible = false;
            this.qualifyingCapitalToolStripMenuItem.Click += new System.EventHandler(this.qualifyingCapitalToolStripMenuItem_Click);
            this.qualifyingCapitalToolStripMenuItem.MouseHover += new System.EventHandler(this.qualifyingCapitalToolStripMenuItem_MouseHover);
            // 
            // underLitigationToolStripMenuItem
            // 
            this.underLitigationToolStripMenuItem.Name = "underLitigationToolStripMenuItem";
            this.underLitigationToolStripMenuItem.Size = new System.Drawing.Size(203, 26);
            this.underLitigationToolStripMenuItem.Text = "Under Litigation";
            this.underLitigationToolStripMenuItem.Visible = false;
            this.underLitigationToolStripMenuItem.Click += new System.EventHandler(this.underLitigationToolStripMenuItem_Click);
            this.underLitigationToolStripMenuItem.MouseHover += new System.EventHandler(this.underLitigationToolStripMenuItem_MouseHover);
            // 
            // summaryReportToolStripMenuItem
            // 
            this.summaryReportToolStripMenuItem.Name = "summaryReportToolStripMenuItem";
            this.summaryReportToolStripMenuItem.Size = new System.Drawing.Size(203, 26);
            this.summaryReportToolStripMenuItem.Text = "Summary Report";
            this.summaryReportToolStripMenuItem.Click += new System.EventHandler(this.summaryReportToolStripMenuItem_Click);
            this.summaryReportToolStripMenuItem.MouseHover += new System.EventHandler(this.summaryReportToolStripMenuItem_MouseHover);
            // 
            // exceptionalReportToolStripMenuItem
            // 
            this.exceptionalReportToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aAFBlankIndustryCodeToolStripMenuItem,
            this.aAFDOSRITAGGINGToolStripMenuItem,
            this.aAFZeroAssetSizeToolStripMenuItem,
            this.iCBSBlankIndustryCodeToolStripMenuItem,
            this.iCBSDOSRITaggingToolStripMenuItem,
            this.iCBSZeroAssetSizeToolStripMenuItem,
            this.differenceInTaggingOfRiskAndGLToolStripMenuItem});
            this.exceptionalReportToolStripMenuItem.Name = "exceptionalReportToolStripMenuItem";
            this.exceptionalReportToolStripMenuItem.Size = new System.Drawing.Size(210, 26);
            this.exceptionalReportToolStripMenuItem.Text = "Exceptional Report";
            // 
            // aAFBlankIndustryCodeToolStripMenuItem
            // 
            this.aAFBlankIndustryCodeToolStripMenuItem.Name = "aAFBlankIndustryCodeToolStripMenuItem";
            this.aAFBlankIndustryCodeToolStripMenuItem.Size = new System.Drawing.Size(324, 26);
            this.aAFBlankIndustryCodeToolStripMenuItem.Text = "AAF - Blank Industry Code";
            this.aAFBlankIndustryCodeToolStripMenuItem.Click += new System.EventHandler(this.aAFBlankIndustryCodeToolStripMenuItem_Click);
            this.aAFBlankIndustryCodeToolStripMenuItem.MouseHover += new System.EventHandler(this.aAFBlankIndustryCodeToolStripMenuItem_MouseHover);
            // 
            // aAFDOSRITAGGINGToolStripMenuItem
            // 
            this.aAFDOSRITAGGINGToolStripMenuItem.Name = "aAFDOSRITAGGINGToolStripMenuItem";
            this.aAFDOSRITAGGINGToolStripMenuItem.Size = new System.Drawing.Size(324, 26);
            this.aAFDOSRITAGGINGToolStripMenuItem.Text = "AAF - DOSRI TAGGING";
            this.aAFDOSRITAGGINGToolStripMenuItem.Click += new System.EventHandler(this.aAFDOSRITAGGINGToolStripMenuItem_Click);
            this.aAFDOSRITAGGINGToolStripMenuItem.MouseHover += new System.EventHandler(this.aAFDOSRITAGGINGToolStripMenuItem_MouseHover);
            // 
            // aAFZeroAssetSizeToolStripMenuItem
            // 
            this.aAFZeroAssetSizeToolStripMenuItem.Name = "aAFZeroAssetSizeToolStripMenuItem";
            this.aAFZeroAssetSizeToolStripMenuItem.Size = new System.Drawing.Size(324, 26);
            this.aAFZeroAssetSizeToolStripMenuItem.Text = "AAF - Zero Asset Size";
            this.aAFZeroAssetSizeToolStripMenuItem.Click += new System.EventHandler(this.aAFZeroAssetSizeToolStripMenuItem_Click);
            this.aAFZeroAssetSizeToolStripMenuItem.MouseHover += new System.EventHandler(this.aAFZeroAssetSizeToolStripMenuItem_MouseHover);
            // 
            // iCBSBlankIndustryCodeToolStripMenuItem
            // 
            this.iCBSBlankIndustryCodeToolStripMenuItem.Name = "iCBSBlankIndustryCodeToolStripMenuItem";
            this.iCBSBlankIndustryCodeToolStripMenuItem.Size = new System.Drawing.Size(324, 26);
            this.iCBSBlankIndustryCodeToolStripMenuItem.Text = "ICBS - Blank Industry Code";
            this.iCBSBlankIndustryCodeToolStripMenuItem.Click += new System.EventHandler(this.iCBSBlankIndustryCodeToolStripMenuItem_Click);
            this.iCBSBlankIndustryCodeToolStripMenuItem.MouseHover += new System.EventHandler(this.iCBSBlankIndustryCodeToolStripMenuItem_MouseHover);
            // 
            // iCBSDOSRITaggingToolStripMenuItem
            // 
            this.iCBSDOSRITaggingToolStripMenuItem.Name = "iCBSDOSRITaggingToolStripMenuItem";
            this.iCBSDOSRITaggingToolStripMenuItem.Size = new System.Drawing.Size(324, 26);
            this.iCBSDOSRITaggingToolStripMenuItem.Text = "ICBS - DOSRI Tagging";
            this.iCBSDOSRITaggingToolStripMenuItem.Click += new System.EventHandler(this.iCBSDOSRITaggingToolStripMenuItem_Click);
            this.iCBSDOSRITaggingToolStripMenuItem.MouseHover += new System.EventHandler(this.iCBSDOSRITaggingToolStripMenuItem_MouseHover);
            // 
            // iCBSZeroAssetSizeToolStripMenuItem
            // 
            this.iCBSZeroAssetSizeToolStripMenuItem.Name = "iCBSZeroAssetSizeToolStripMenuItem";
            this.iCBSZeroAssetSizeToolStripMenuItem.Size = new System.Drawing.Size(324, 26);
            this.iCBSZeroAssetSizeToolStripMenuItem.Text = "ICBS - Zero Asset Size";
            this.iCBSZeroAssetSizeToolStripMenuItem.Click += new System.EventHandler(this.iCBSZeroAssetSizeToolStripMenuItem_Click);
            this.iCBSZeroAssetSizeToolStripMenuItem.MouseHover += new System.EventHandler(this.iCBSZeroAssetSizeToolStripMenuItem_MouseHover);
            // 
            // differenceInTaggingOfRiskAndGLToolStripMenuItem
            // 
            this.differenceInTaggingOfRiskAndGLToolStripMenuItem.Name = "differenceInTaggingOfRiskAndGLToolStripMenuItem";
            this.differenceInTaggingOfRiskAndGLToolStripMenuItem.Size = new System.Drawing.Size(324, 26);
            this.differenceInTaggingOfRiskAndGLToolStripMenuItem.Text = "Difference in Tagging of Risk and GL";
            this.differenceInTaggingOfRiskAndGLToolStripMenuItem.Click += new System.EventHandler(this.differenceInTaggingOfRiskAndGLToolStripMenuItem_Click);
            this.differenceInTaggingOfRiskAndGLToolStripMenuItem.MouseHover += new System.EventHandler(this.differenceInTaggingOfRiskAndGLToolStripMenuItem_MouseHover);
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.Location = new System.Drawing.Point(160, 137);
            this.metroLabel2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(111, 20);
            this.metroLabel2.TabIndex = 96;
            this.metroLabel2.Text = "Selected Report:";
            // 
            // txtRptName
            // 
            this.txtRptName.BackColor = System.Drawing.Color.White;
            // 
            // 
            // 
            this.txtRptName.CustomButton.Image = null;
            this.txtRptName.CustomButton.Location = new System.Drawing.Point(339, 2);
            this.txtRptName.CustomButton.Margin = new System.Windows.Forms.Padding(4);
            this.txtRptName.CustomButton.Name = "";
            this.txtRptName.CustomButton.Size = new System.Drawing.Size(29, 29);
            this.txtRptName.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtRptName.CustomButton.TabIndex = 1;
            this.txtRptName.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtRptName.CustomButton.UseSelectable = true;
            this.txtRptName.CustomButton.Visible = false;
            this.txtRptName.FontSize = MetroFramework.MetroTextBoxSize.Medium;
            this.txtRptName.Lines = new string[0];
            this.txtRptName.Location = new System.Drawing.Point(304, 128);
            this.txtRptName.Margin = new System.Windows.Forms.Padding(4);
            this.txtRptName.MaxLength = 32767;
            this.txtRptName.Name = "txtRptName";
            this.txtRptName.PasswordChar = '\0';
            this.txtRptName.ReadOnly = true;
            this.txtRptName.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtRptName.SelectedText = "";
            this.txtRptName.SelectionLength = 0;
            this.txtRptName.SelectionStart = 0;
            this.txtRptName.Size = new System.Drawing.Size(371, 34);
            this.txtRptName.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtRptName.TabIndex = 98;
            this.txtRptName.UseSelectable = true;
            this.txtRptName.WaterMark = "Name of the Report";
            this.txtRptName.WaterMarkColor = System.Drawing.Color.Silver;
            this.txtRptName.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.txtRptName.TextChanged += new System.EventHandler(this.txtRptName_TextChanged);
            // 
            // btnExport
            // 
            this.btnExport.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnExport.Location = new System.Drawing.Point(1315, 126);
            this.btnExport.Margin = new System.Windows.Forms.Padding(4);
            this.btnExport.Name = "btnExport";
            this.btnExport.Size = new System.Drawing.Size(148, 36);
            this.btnExport.TabIndex = 99;
            this.btnExport.Text = "&Export To Excel";
            this.btnExport.UseCustomBackColor = true;
            this.btnExport.UseCustomForeColor = true;
            this.btnExport.UseSelectable = true;
            this.btnExport.UseStyleColors = true;
            this.btnExport.Click += new System.EventHandler(this.btnExport_Click);
            // 
            // frmReportViewer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1601, 780);
            this.Controls.Add(this.btnExport);
            this.Controls.Add(this.reportViewer1);
            this.Controls.Add(this.txtRptName);
            this.Controls.Add(this.metroLabel2);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.pnlWaitInfo);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btnExecute);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.Name = "frmReportViewer";
            this.Padding = new System.Windows.Forms.Padding(27, 74, 27, 25);
            this.ShadowType = MetroFramework.Forms.MetroFormShadowType.DropShadow;
            this.Style = MetroFramework.MetroColorStyle.Yellow;
            this.Text = "NTC Report Viewer";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.frmReportViewer_FormClosed);
            this.Load += new System.EventHandler(this.frmReportViewer_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.pnlWaitInfo.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ConsoMenu.ResumeLayout(false);
            this.ConsoMenu.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Microsoft.Reporting.WinForms.ReportViewer reportViewer1;
        private MetroFramework.Controls.MetroButton btnExecute;
        private System.Windows.Forms.Panel panel1;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        internal MetroFramework.Controls.MetroDateTime cmbDateTo;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        internal MetroFramework.Controls.MetroDateTime cmbDateFrom;
        private System.Windows.Forms.Panel pnlWaitInfo;
        private MetroFramework.Controls.MetroLabel lblWaitStatus1;
        private MetroFramework.Controls.MetroLabel lblWaitFilePath;
        private MetroFramework.Controls.MetroLabel lblWaitStatus;
        private MetroFramework.Controls.MetroLabel lblWaitInfo;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.ToolStrip ConsoMenu;
        private System.Windows.Forms.ToolStripDropDownButton toolStripButton1;
        private System.Windows.Forms.ToolStripMenuItem nTCReportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exceptionalReportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aAFBlankIndustryCodeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aAFDOSRITAGGINGToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aAFZeroAssetSizeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem iCBSBlankIndustryCodeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem iCBSDOSRITaggingToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem iCBSZeroAssetSizeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem differenceInTaggingOfRiskAndGLToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem consolidatorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem correspondingGLToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dailyGLToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exchangeRateToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem migratedAccountToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pastDueToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem qualifyingCapitalToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem underLitigationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem summaryReportToolStripMenuItem;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroTextBox txtRptName;
        private MetroFramework.Controls.MetroButton btnExport;
    }
}