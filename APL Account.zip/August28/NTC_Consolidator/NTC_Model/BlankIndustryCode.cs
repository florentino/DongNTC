﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NTC_Consolidator.NTC_Model
{
    public class BlankIndustryCode
    {
        private string _AccountNo;

        public string AccountNo
        {
            get { return _AccountNo; }
            set { _AccountNo = value; }
        }

        private string _ClientName;

        public string ClientName
        {
            get { return _ClientName; }
            set { _ClientName = value; }
        }

        private string _AO;

        public string AO
        {
            get { return _AO; }
            set { _AO = value; }
        }

        private string _PerFaMSAAFICBSIndustryCode;

        public string PerFaMSAAFICBSIndustryCode
        {
            get { return _PerFaMSAAFICBSIndustryCode; }
            set { _PerFaMSAAFICBSIndustryCode = value; }
        }

        private string _IndustryHeader;

        public string IndustryHeader
        {
            get { return _IndustryHeader; }
            set { _IndustryHeader = value; }
        }

        private string _IndustryDetail;

        public string IndustryDetail
        {
            get { return _IndustryDetail; }
            set { _IndustryDetail = value; }
        }


    }
}
