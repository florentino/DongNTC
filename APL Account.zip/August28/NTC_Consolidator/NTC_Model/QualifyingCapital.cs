﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NTC_Consolidator.Model
{
    public class QualifyingCapital
    {
        private int _QualifyingCapitalID;
        private string _Description;
        private decimal _Amount;
        private DateTime _CreatedDate;
        private string _CreatedBy;
        private DateTime _RefDate;
        private bool _isDeleted;

        public bool isDeleted
        {
            get { return _isDeleted; }
            set { _isDeleted = value; }
        }

        public DateTime RefDate
        {
            get { return _RefDate; }
            set { _RefDate = value; }
        }


        public string CreatedBy
        {
            get { return _CreatedBy; }
            set { _CreatedBy = value; }
        }

        public DateTime CreatedDate
        {
            get { return _CreatedDate; }
            set { _CreatedDate = value; }
        }

        [Required(ErrorMessage = "Amount is required.")]
        [RegularExpression(@"\d{1,16}\.?|\d{0,16}\.\d{1,3}$", ErrorMessage = "Amount must be greater than zero.")]
        public decimal Amount
        {
            get { return _Amount; }
            set
            {
                Validator.ValidateProperty(value, new ValidationContext(this, null, null) { MemberName = "Amount" });
                _Amount = value;
            }
        }

        [Required(ErrorMessage = "Description is required.")]
        public string Description
        {
            get { return _Description; }
            set
            {
                Validator.ValidateProperty(value, new ValidationContext(this, null, null) { MemberName = "Description" });
                _Description = value;
            }
        }

        public int QualifyingCapitalID
        {
            get { return _QualifyingCapitalID; }
            set { _QualifyingCapitalID = value; }
        }

    }
}
