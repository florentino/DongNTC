﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NTC_Consolidator.Model
{
    public class ExchangeRate
    {
        private string _CurrencyCode;
        private decimal _CurrencyRate;
        private DateTime _CreatedDate;
        private string _CreatedBy;
        private int _CurrencyID;
        private DateTime _DateTimeRate;
        private bool _isDeleted;

        public bool isDeleted
        {
            get { return _isDeleted; }
            set { _isDeleted = value; }
        }


        public DateTime DateTimeRate
        {
            get { return _DateTimeRate; }
            set { _DateTimeRate = value; }
        }


        public int CurrencyID
        {
            get { return _CurrencyID; }
            set { _CurrencyID = value; }
        }

        public string CreatedBy
        {
            get { return _CreatedBy; }
            set { _CreatedBy = value; }
        }

        public DateTime CreatedDate
        {
            get { return _CreatedDate; }
            set { _CreatedDate = value; }
        }

        [Required(ErrorMessage = "Currency Type is required.")]
        public string CurrencyCode
        {
            get { return _CurrencyCode; }
            set
            {
                Validator.ValidateProperty(value, new ValidationContext(this, null, null) { MemberName = "CurrencyCode" });
                _CurrencyCode = value;
            }
        }

        [Required(ErrorMessage = "Currency Rate is required.")]
        [RegularExpression(@"\d{1,16}\.?|\d{0,16}\.\d{1,3}$", ErrorMessage = "Amount must be greater than zero.")]
        public decimal CurrencyRate
        {
            get { return _CurrencyRate; }
            set
            {
                Validator.ValidateProperty(value, new ValidationContext(this, null, null) { MemberName = "CurrencyRate" });
                _CurrencyRate = value;
            }
        }


    }
}
